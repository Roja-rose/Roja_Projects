# ----- Phase 0: Imports & Setup -----
#pip install sqlalchemy, pandas, psycopg2, psycopg2-binary
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from pulp import LpProblem, LpVariable, LpMaximize, LpInteger
import matplotlib.pyplot as plt
from sqlalchemy import create_engine
import os

#Phase 1: Database Connection Setup
def connect_to_database():
    conn_params = {
    "host" : "ttc-data-traffic-data.b.aivencloud.com",
    "database" : "defaultdb",
    "user" : "group4ttc",
    "password" : "Gr0up$004",
    "port" : "25159"
    }
    engine = create_engine(f"postgresql+psycopg2://{conn_params['user']}:{conn_params['password']}@{conn_params['host']}:{conn_params['port']}/{conn_params['database']}?sslmode=require")
    return engine

def read_table(table_name):
    cxn = connect_to_database()
    query = f'SELECT * FROM gold."gold.{table_name}";'
    df = pd.read_sql_query(query, cxn)
    return df

# Main execution (all code to be run inside "if __name__ == '__main__':" statement)
if __name__ == "__main__":
    # ----- Phase 2: Riders regression analysis and cost regression analysis -----
    # Riders regression Analysis (check linearity for decision variables coefficients):
    # Read fact_transit table
    transit_df = read_table("fact_transit")
    route_df = read_table("dim_route")
    print(transit_df.columns)
    print(route_df.columns)

    reg_X = transit_df[['trips_per_day', 'hours_per_day']]
    reg_y = transit_df['riders_per_day']

    reg_model = LinearRegression()
    reg_model.fit(reg_X, reg_y)

    x, y = reg_model.coef_
    intercept = reg_model.intercept_

    print("\nRegression Coefficients:")
    print(f"x (Trips): {x:.2f}, y (Hours): {y:.2f}")
    print(f"Intercept: {intercept:.2f}")
    print(f"R² Score: {reg_model.score(reg_X, reg_y):.4f}")

    # ----- Visualize Linear Relationships -----
    #plt.figure(figsize=(12, 4))

    # Trips vs Riders
    # plt.subplot(1, 3, 1)
    # plt.scatter(transit_df['trips_per_day'], transit_df['riders_per_day'], color='blue')
    # plt.title('Trips vs Riders')
    # plt.xlabel('Trips per Day')
    # plt.ylabel('Riders per Day')

    # # Service Hours vs Riders
    # plt.subplot(1, 3, 2)
    # plt.scatter(transit_df['hours_per_day'], transit_df['riders_per_day'], color='green')
    # plt.title('Service Hours vs Riders')
    # plt.xlabel('Operating Hours')
    # plt.ylabel('Riders per Day')


    # plt.tight_layout()
    # plt.show()

    # Cost Regression Analysis (find marginal costs)
    # Prepare features and target
    X_cost = transit_df[['trips_per_day', 'hours_per_day']]
    y_cost = transit_df['operational_cost_per_day']

    #Fit linear regression model
    cost_model = LinearRegression()
    cost_model.fit(X_cost, y_cost)

    # Extract results
    cost_per_trip, cost_per_hour = cost_model.coef_
    intercept_cost = cost_model.intercept_
    r2_cost = cost_model.score(X_cost, y_cost)

    print("\n=== COST REGRESSION RESULTS ===")
    print(f"Intercept: {intercept_cost:.2f}")
    print(f"Cost per Trip (relative importance): {cost_per_trip:.4f}")
    print(f"Cost per Service Hour (relative importance): {cost_per_hour:.4f}")
    print(f"R² Score: {r2_cost:.4f}")

    # ----- Phase 3: Create Dataframe for inputted routes -----
    # Ask user to input one or more route IDs (comma-separated)
    user_input = input("\nEnter route_id(s) to optimize (comma-separated): ").strip()

    # Parse and strip input
    found = [r.strip() for r in user_input.split(",") if r.strip()]

    # Normalize types
    # If route_id column is numeric, convert found to numeric
    if pd.api.types.is_numeric_dtype(transit_df['route_id']):
        found = [int(r) if r.isdigit() else r for r in found]
    else:
        # Otherwise make sure both are strings
        transit_df['route_id'] = transit_df['route_id'].astype(str)
        found = [str(r) for r in found]

    # Validate input
    missing_routes = [r for r in found if r not in transit_df['route_id'].values]
    if missing_routes:
        raise ValueError(f"Error: The following route_id(s) not found in transit_df: {missing_routes}")

    print(f"\nRoutes selected for optimization: {found}")
    #Note: Target routes used - 74968,74833,74821,74803,74796

    # Create dataset
    before_per_day = (
        transit_df[transit_df['route_id'].isin(found)]
        [['route_id','riders_per_day', 'riders_per_hour', 'riders_per_trip',
        'operational_cost_per_rider','operational_cost_per_day',
        'trips_per_day', 'hours_per_day']]
        .drop_duplicates(subset='route_id', keep='first')
        .reset_index(drop=True)
    )

    # Convert KPIs to integer type
    before_per_day = before_per_day.assign(
        riders_per_day=lambda df: df['riders_per_day'].astype(int),
        riders_per_hour=lambda df: df['riders_per_hour'].astype(int),
        riders_per_trip=lambda df: df['riders_per_trip'].astype(int),
        trips_per_day=lambda df: df['trips_per_day'].astype(int)
    )

    print("=== BEFORE DATA ===")
    print(before_per_day[['route_id', 'trips_per_day', 'hours_per_day',
                        'operational_cost_per_day', 'riders_per_day']])

    # ----- Phase 4: Define Optimization Model (MILP) -----
    results = []
    for route in before_per_day['route_id']:
        print(f"\n--- OPTIMIZATION FOR ROUTE {route} ---")
        model = LpProblem("Route_Optimization", LpMaximize)

        # Get base values for reference
        base_trips = before_per_day.loc[before_per_day['route_id'] == route, 'trips_per_day'].values[0]
        base_hours = before_per_day.loc[before_per_day['route_id'] == route, 'hours_per_day'].values[0]
        base_cost  = before_per_day.loc[before_per_day['route_id'] == route, 'operational_cost_per_day'].values[0]

        # Get user-defined bounds with defaults
        print(f"\nEnter bounds for Route {route} (press Enter to use default):")
        trips_min = int(input(f"  Minimum Trips Per Day (Default is 97% of current trips ({base_trips}) - {0.97*base_trips:.2f}): ") or 0.97*base_trips)
        trips_max = int(input(f"  Maximum Trips Per Day (Default is 103% of current trips ({base_trips}) - {1.03*base_trips:.2f}): ") or 1.03*base_trips)
        hours_min = float(input(f"  Minimum Operational Hours Per Day (Default is 97% of current hours ({base_hours}) - {0.97*base_hours:.2f}): ") or 0.97*base_hours)
        hours_max = float(input(f"  Maximum Operational Hours Per Day (Default is 103% of current hours ({base_hours}) - {1.03*base_hours:.2f}): ") or 1.03*base_hours)
        cost_max = float(input(f"  Maximum Operational Cost Per Day (Default is 102% of current cost ({base_cost}) - {1.02*base_cost:.2f}): ") or 1.02*base_cost)

        # Decision Variables
        trips = LpVariable("Trips", lowBound=trips_min, upBound=trips_max, cat=LpInteger)
        hours = LpVariable("Hours", lowBound=hours_min, upBound=hours_max)

        # Objective Function: Maximize riders
        model += x * trips + y * hours, "Maximize_Riders"

        # Constraints
        # Trips bounds
        model += trips >= trips_min
        model += trips <= trips_max
        # Hours bounds
        model += hours >= hours_min
        model += hours <= hours_max
        # Cost constraint
        cost = cost_per_trip * trips + cost_per_hour * hours
        model += cost_max >= cost
        # Relationship constraint: hours
        hours_per_trip =transit_df.loc[transit_df['route_id'] == route, 'route_duration'].iloc[0]
        model += hours >= hours_per_trip * trips
        # Bus capacity constraint
        bus_max = route_df.loc[route_df['route_id'] == route, 'bus_capacity'].values[0]
        model += bus_max * trips >= x * trips + y * hours

        # ----- Phase 5: Solve the Model -----
        model.solve()

        opt_trips = trips.value()
        opt_hours = hours.value()
        opt_cost = intercept_cost + cost_per_trip * opt_trips + cost_per_hour * opt_hours
        opt_riders = intercept + x * opt_trips + y * opt_hours

        results.append({
            'route_id': route,
            'expected_riders_per_day': int(opt_riders),
            'opt_riders_per_hour': int(opt_riders / opt_hours),
            'opt_riders_per_trip': int(opt_riders / opt_trips),
            'opt_operational_cost_per_day': opt_cost,
            'opt_operational_cost_per_rider': opt_cost / opt_riders,
            'opt_trips_per_day': int(opt_trips),
            'opt_hours_per_day': opt_hours
        })
    after_per_day = pd.DataFrame(results)

    # ----- Phase 6: Scenario Testing (Before vs After) -----
    for route in before_per_day['route_id'].unique():
        before_row = before_per_day.loc[before_per_day['route_id'] == route].reset_index(drop=True)
        after_row = after_per_day.loc[after_per_day['route_id'] == route].reset_index(drop=True)

        # Rename columns for 'after' row
        after_row = after_row.rename(columns={
            'expected_riders_per_day': 'riders_per_day',
            'opt_riders_per_hour': 'riders_per_hour',
            'opt_riders_per_trip': 'riders_per_trip',
            'opt_operational_cost_per_day': 'operational_cost_per_day',
            'opt_operational_cost_per_rider': 'operational_cost_per_rider',
            'opt_trips_per_day': 'trips_per_day',
            'opt_hours_per_day': 'hours_per_day',
        })

        # Combine them for comparison
        comparison = pd.concat([before_row, after_row], ignore_index=True)
        comparison.index = ['Before', 'After']

        # Compute percentage change ((After - Before) / Before) * 100
        percent_change = ((comparison.loc['After'] - comparison.loc['Before']) / comparison.loc['Before']) * 100
        percent_change = percent_change.to_frame().T
        percent_change.index = ['% Change']

        # Preparing columns for Target Achieved row
        optm_cols = ['trips_per_day', 'hours_per_day','operational_cost_per_day']
        cost_col = ['operational_cost_per_rider']

        # Function to compute Target Achieved status
        def achieve_status(col_name, pct_value):
            # "Optimized" for trips & hours
            if col_name in optm_cols:
                return "Optimized"
            
            # Cost decreases by 7% or more - Achieved
            if col_name in cost_col:
                return "Yes" if pct_value <= -7 else "No"
            
            # route_id column, return N/A
            if col_name == 'route_id':
                return "N/A"
            
            # Default: increase of 7% or more - Achieved
            return "Yes" if pct_value >= 7 else "No"

        # Build Target Achieved row
        target_achieved = percent_change.apply(
            lambda col: achieve_status(col.name, col.iloc[0])
        )
        target_achieved = target_achieved.to_frame().T
        target_achieved.index = ["Target Achieved"]

        # Append rows
        comparison = pd.concat([comparison, percent_change, target_achieved], axis=0)

        print(f"\n=== BEFORE VS AFTER COMPARISON FOR ROUTE {route} ===")
        print(comparison[['riders_per_day', 'riders_per_hour', 'riders_per_trip',
                        'operational_cost_per_rider','operational_cost_per_day',
                        'trips_per_day','hours_per_day']])

        # Ensure results directory exists
        output_dir = "results"
        os.makedirs(output_dir, exist_ok=True)

        # Ensure results directory exists under the Optimize&ScenarioTest folder (same folder as this script)
        script_dir = os.path.dirname(__file__)
        output_dir = os.path.join(script_dir, "results")
        os.makedirs(output_dir, exist_ok=True)

        # Select only numeric rows for plotting
        numeric_rows = ['Before', 'After', '% Change']

        comparison_numeric = comparison.loc[numeric_rows]

        # Visualization
        comparison_numeric[['riders_per_hour', 'riders_per_trip','operational_cost_per_rider',
                    'trips_per_day','hours_per_day']].plot.bar(title=f'Route {route}: Before vs After Optimization', rot=0
        )
        plt.ylabel('Value')
        plt.tight_layout()

        # Save figure as PNG
        output_path = os.path.join(output_dir, f"comparison_plot_route_{route}.png")
        plt.savefig(output_path, dpi=300)
        plt.show()
        plt.close() 

        # Save comparison table as CSV
        comparison.to_csv(os.path.join(output_dir, f"comparison_table_route_{route}.csv"), index=True)