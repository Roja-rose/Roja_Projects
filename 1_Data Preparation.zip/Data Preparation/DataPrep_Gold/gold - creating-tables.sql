SET search_path TO gold, public; 

SET search_path TO silver, gold, public; 
-- 1. Create dim_route from silver.route_clean
CREATE TABLE gold.dim_route
AS
SELECT *
FROM "silver.route_clean";

---Renaming table name
ALTER TABLE dim_route RENAME TO "gold.dim_route";

--validating row count---
---Result: 194 same as silver.route_clean
select count(*) from "gold.dim_route"

-- Checking for table view
SELECT * FROM "gold.dim_route" limit 5;


-- 2. Create dim_trip from silver.trip_clean
CREATE TABLE gold.dim_trip
AS
SELECT *
FROM "silver.trip_clean";

---Renaming table name
ALTER TABLE dim_trip RENAME TO "gold.dim_trip";

--validating row count---
---Result: 32604 same as silver.route_clean
select count(*) from "gold.dim_trip"

-- Checking for table view
SELECT * FROM "gold.dim_trip" limit 5;

-- 3. Create dim_stop from silver.stop_clean
CREATE TABLE gold.dim_stop
AS
SELECT *
FROM "silver.stop_clean";

---Renaming table name
ALTER TABLE dim_stop RENAME TO "gold.dim_stop";

--validating row count---
---Result: 1056104 same as silver.stop_clean
select count(*) from "gold.dim_stop"

-- Checking for table view
SELECT * FROM "gold.dim_stop" limit 5;

-- 4. Create dim_stop_description from silver.stop_description_clean
CREATE TABLE gold.dim_stop_description
AS
SELECT *
FROM "silver.stop_description_clean";

---Renaming table name
ALTER TABLE dim_stop_description RENAME TO "gold.dim_stop_description";

--validating row count---
---Result: 8538 same as silver.stop_description_clean
select count(*) from "gold.dim_stop_description"

-- Checking for table view
SELECT * FROM "gold.dim_stop_description" limit 5;

-- 5. Create fact_transit from silver.transit_final_clean
CREATE TABLE gold.fact_transit
AS
SELECT *
FROM "silver.transit_final_clean";

---Renaming table name
ALTER TABLE fact_transit RENAME TO "gold.fact_transit";

--validating row count---
---Result: 1051045 same as silver.transit_final_clean
select count(*) from "gold.fact_transit"

-- Checking for table view
SELECT * FROM "gold.fact_transit" limit 5;
