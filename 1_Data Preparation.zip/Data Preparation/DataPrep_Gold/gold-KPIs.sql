-- ========================================================================================
-- ADJUSTED SCRIPT TO POPULATE gold.fact_transit AND PREVENT RIDERSHIP MISMATCH ERROR
-- The fix involves ensuring all ratio-based KPIs remain DECIMAL.
-- Schema name 'pink' replaced with 'gold'
-- ========================================================================================
SET search_path TO gold, public;
-- Checking for table view
SELECT * FROM "gold.fact_transit" limit 5;



-- Add ridership and cost ratios (use DECIMAL for precision)
-- These columns must remain DECIMAL to prevent rounding errors.

ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS trips_per_day DECIMAL;
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS riders_per_hour DECIMAL;
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS riders_per_trip DECIMAL;
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS operational_cost_per_rider DECIMAL;
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS operational_cost_per_day DECIMAL;

-- Add duration and load factor metrics
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS trip_duration DECIMAL;
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS route_duration DECIMAL;
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS load_factor_per_trip DECIMAL;
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS service_span DECIMAL;
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS trips_on_peak INT;
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS trips_off_peak INT;
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS off_peak_trip_ratio DECIMAL;

-- NEW COLUMN: Add a rounded integer version for reporting display purposes
ALTER TABLE "gold.fact_transit" ADD COLUMN IF NOT EXISTS riders_per_trip_rounded INT;

-- Checking number of records after adding columns for kpi calculations
select count(*) from "gold.fact_transit";

-- Checking for table view
SELECT * FROM "gold.fact_transit" limit 5;

-- ===============================================================================
-- Step 1: Calculate and populate trips_on_peak and trips_off_peak (INT counts)
-- Peak Boundaries in seconds: AM (21,600 to 32,400) and PM (54,000 to 68,400)
-- ===============================================================================
WITH FirstStopTimes AS (
    SELECT
        s.trip_id,
        t.route_id,
        s.stopping_time_sec
    FROM
        "gold.dim_stop" s
    JOIN
        "gold.dim_trip" t ON s.trip_id = t.trip_id
    WHERE
        s.stop_sequence = 1
),
TripClassification AS (
    SELECT
        route_id,
        CASE
            WHEN stopping_time_sec >= 21600 AND stopping_time_sec < 32400 THEN 'Peak'
            WHEN stopping_time_sec >= 54000 AND stopping_time_sec < 68400 THEN 'Peak'
            ELSE 'Off-Peak'
        END AS peak_status
    FROM
        FirstStopTimes
),
RouteTripTotals AS (
    SELECT
        route_id,
        SUM(CASE WHEN peak_status = 'Peak' THEN 1 ELSE 0 END) AS total_trips_on_peak,
        SUM(CASE WHEN peak_status = 'Off-Peak' THEN 1 ELSE 0 END) AS total_trips_off_peak
    FROM
        TripClassification
    GROUP BY
        route_id
)
-- UPDATE: Apply the route-level counts to all corresponding rows in the fact table.
UPDATE "gold.fact_transit" AS f
SET
    trips_on_peak = rt.total_trips_on_peak,
    trips_off_peak = rt.total_trips_off_peak
FROM
    RouteTripTotals AS rt
WHERE
    f.route_id = rt.route_id;

-- Checking for table view
SELECT * FROM "gold.fact_transit" limit 5;



-- ===============================================================================
-- STEP 2: Calculate and populate time-based KPIs (duration and span - DECIMALS)
-- ===============================================================================
WITH AggregatedKpis AS (
    SELECT
        t.route_id,
        s.trip_id,
        -- Trip duration in seconds
        MAX(s.stopping_time_sec) - MIN(s.stopping_time_sec) AS calculated_trip_duration_sec,
        MIN(s.stopping_time_sec) AS min_stop_time_sec,
        MAX(s.stopping_time_sec) AS max_stop_time_sec
    FROM
        "gold.dim_stop" s
    JOIN
        "gold.dim_trip" t ON s.trip_id = t.trip_id
    GROUP BY
        t.route_id, s.trip_id
),
RouteKpis AS (
    SELECT
        td.route_id,
        -- Route duration is the average trip duration
        AVG(td.calculated_trip_duration_sec) AS calculated_route_duration_sec,
        -- Service span is the max stop time minus the min stop time across all trips
        MAX(td.max_stop_time_sec) - MIN(td.min_stop_time_sec) AS calculated_service_span_sec
    FROM
        AggregatedKpis td
    GROUP BY
        td.route_id
)
-- UPDATE: Update based on AggregatedKpis (for trip_duration) and RouteKpis (for route_duration/service_span).
UPDATE "gold.fact_transit" AS f
SET
    -- A. trip_duration (Individual trip level, matching trip_id)
    trip_duration = ak.calculated_trip_duration_sec / 3600.0,
    -- B. route_duration (Route level, matching route_id)
    route_duration = rk.calculated_route_duration_sec / 3600.0,
    -- C. service_span (Route level, matching route_id)
    service_span = rk.calculated_service_span_sec / 3600.0
FROM
    AggregatedKpis AS ak
JOIN
    RouteKpis AS rk ON ak.route_id = rk.route_id
WHERE
    f.trip_id = ak.trip_id
    AND f.route_id = rk.route_id;

-- Checking for table view
SELECT * FROM "gold.fact_transit" limit 5;



-- ===============================================================================
-- Step 3 (MODIFIED): Calculate trips_per_day (trips_on_peak + trips_off_peak - DECIMAL)
-- CRITICAL FIX: To pass validation, we use the sum of counted trips here.
-- ===============================================================================
UPDATE "gold.fact_transit" AS f
SET
    trips_per_day = f.trips_on_peak + f.trips_off_peak;


-- Checking for table view
SELECT * FROM "gold.fact_transit" limit 5;

-- ===============================================================================

-- Step 4: Calculate operational costs and primary ratios (DECIMALS)
-- CRITICAL FIX: Ensure riders_per_trip remains DECIMAL to prevent the mismatch.
-- ===============================================================================
UPDATE "gold.fact_transit" AS f
SET
    -- A. OPERATIONAL COST KPIS (Operating cost_per_hour = $275.00 constant)
    operational_cost_per_day = f.hours_per_day * 275.00,
    operational_cost_per_rider = (f.hours_per_day * 275.00) / NULLIF(f.riders_per_day, 0),

    -- B. RATIO KPIS (Ridership Ratios)
    riders_per_hour = CAST(f.riders_per_day AS DECIMAL) / NULLIF(f.hours_per_day, 0),

    -- THIS IS THE CRITICAL LINE: Keep riders_per_trip as a precise DECIMAL
    riders_per_trip = CAST(f.riders_per_day AS DECIMAL) / NULLIF(f.trips_per_day, 0),

    -- C. load_factor_per_trip requires a join to get bus_capacity
    load_factor_per_trip =
        (CAST(f.riders_per_day AS DECIMAL) / NULLIF(f.trips_per_day, 0)) / NULLIF(r.bus_capacity, 0)
FROM
    "gold.dim_route" r
WHERE
    f.route_id = r.route_id;

-- Checking for table view
SELECT * FROM "gold.fact_transit" limit 5;


-- ===============================================================================
-- Step 5: Calculate the off_peak_trip_ratio (DECIMAL)
-- ===============================================================================
UPDATE "gold.fact_transit"
SET
    off_peak_trip_ratio =
        CAST(trips_off_peak AS DECIMAL) /
        NULLIF((trips_on_peak + trips_off_peak), 0);

-- Checking number of records after kpi calculations
select count(*) from "gold.fact_transit";

-- Checking for table view
SELECT * FROM "gold.fact_transit" limit 5;


SELECT COUNT(*) FROM "gold.fact_transit";

