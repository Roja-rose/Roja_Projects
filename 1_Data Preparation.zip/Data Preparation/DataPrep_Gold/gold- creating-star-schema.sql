SET search_path TO gold, public; 

--1- Set Primary Key on gold.dim_route
ALTER TABLE "gold.dim_route"
ADD CONSTRAINT pk_dim_route PRIMARY KEY (route_id);

--validating row count---
---Result: 194 :correct
select count(*) from "gold.dim_route"

-- Checking for table view
SELECT * FROM "gold.dim_route" limit 5;

---Validation Test
-- Test Name: PK Uniqueness Check (Duplicate ID 74818)
-- EXPECTED ERROR: ERROR: duplicate key value violates unique constraint "pk_dim_route"
---Result:successful
INSERT INTO "gold.dim_route" (route_id, route_long_name, route_type)
VALUES (74818, 'Duplicate Route Test', 3);

-- Test Name: PK NOT NULL Check (NULL ID)
-- EXPECTED ERROR: ERROR: null value in column "route_id" violates not-null constraint
----Result: successful
INSERT INTO "gold.dim_route" (route_id, route_long_name, route_type)
VALUES (NULL, 'Null Route Test', 3);

--2. Set Primary Key on gold.dim_trip
ALTER TABLE "gold.dim_trip"
ADD CONSTRAINT pk_dim_trip PRIMARY KEY (trip_id);

--validating row count---
---Result: 32604: correct
select count(*) from "gold.dim_trip"

-- Checking for table view
SELECT * FROM "gold.dim_trip" limit 5;

-- Test Name: PK Uniqueness Check (Duplicate ID 49014911)
-- EXPECTED ERROR: ERROR: duplicate key value violates unique constraint "pk_dim_trip"
---Result: successful
INSERT INTO "gold.dim_trip" (trip_id, route_id)
VALUES (49014911, 74750);

-- Test Name: PK NOT NULL Check (NULL ID)
-- EXPECTED ERROR: ERROR: null value in column "trip_id" violates not-null constraint
---Result: successful
INSERT INTO "gold.dim_trip" (trip_id, route_id)
VALUES (NULL, 74750);

--3. Set Primary Key on gold.dim_stop_description
ALTER TABLE "gold.dim_stop_description"
ADD CONSTRAINT pk_dim_stop_desc PRIMARY KEY (stop_id);

--validating row count---
---Result: 8538 :correct
select count(*) from "gold.dim_stop_description"

-- Checking for table view
SELECT * FROM "gold.dim_stop_description" limit 5;

-- Test Name: PK Uniqueness Check (Duplicate ID 262)
-- EXPECTED ERROR: ERROR: duplicate key value violates unique constraint "pk_dim_stop_desc"
---Result: successful
INSERT INTO "gold.dim_stop_description" (stop_id, stop_name)
VALUES (262, 'Duplicate Stop Test');

-- Test Name: PK NOT NULL Check (NULL ID)
-- EXPECTED ERROR: ERROR: null value in column "stop_id" violates not-null constraint
---Result: successful
INSERT INTO "gold.dim_stop_description" (stop_id, stop_name)
VALUES (NULL, 'Null Stop Test');

--4. Set Primary Key on gold.dim_stop
ALTER TABLE "gold.dim_stop"
ADD CONSTRAINT pk_dim_stop PRIMARY KEY (trip_stop_sequence_id);

-- Link dim_stop (Child) to dim_stop_description (Parent)
ALTER TABLE "gold.dim_stop"
ADD CONSTRAINT fk_stop_to_desc
FOREIGN KEY (stop_id) REFERENCES "gold.dim_stop_description" (stop_id);

--validating row count---
---Result: 1056104 :correct
select count(*) from "gold.dim_stop"

-- Checking for table view
SELECT * FROM "gold.dim_stop" limit 5;

-- Test Name: PK Uniqueness Check (Duplicate ID 3490024)
-- EXPECTED ERROR: ERROR: duplicate key value violates unique constraint "pk_dim_stop"
---Result: successful
INSERT INTO "gold.dim_stop" (trip_stop_sequence_id, stop_id, trip_id)
VALUES (3490024, 9528, 49133408);

-- Test Name: PK NOT NULL Check (NULL ID)
-- EXPECTED ERROR: ERROR: null value in column "trip_stop_sequence_id" violates not-null constraint
---Result: successful
INSERT INTO "gold.dim_stop" (trip_stop_sequence_id, stop_id, trip_id)
VALUES (NULL, 100, 100);

-- Test Name: FK Check (stop_id: 55555 does not exist in dim_stop_description)
-- EXPECTED ERROR: ERROR: insert or update on table "dim_stop" violates foreign key constraint "fk_stop_to_desc"
--Result: successful
INSERT INTO "gold.dim_stop" (trip_stop_sequence_id, stop_id, trip_id)
VALUES (0, 55555, 49133408);

--Linking fact with dimensions
-- 5. Link fact_transit to dim_route (using route_id)
ALTER TABLE "gold.fact_transit"
ADD CONSTRAINT fk_fact_route
FOREIGN KEY (route_id) REFERENCES "gold.dim_route" (route_id);

---validation test
-- Test Name: FK Check (route_id: 555 does not exist in dim_route)
-- EXPECTED ERROR: ERROR: insert or update on table "fact_transit" violates foreign key constraint "fk_fact_route"
INSERT INTO "gold.fact_transit" (route_id, trip_id, trip_stop_sequence_id)
VALUES (555, 999, 99999);

-- 6. Link fact_transit to dim_trip (using trip_id)
ALTER TABLE "gold.fact_transit"
ADD CONSTRAINT fk_fact_trip
FOREIGN KEY (trip_id) REFERENCES "gold.dim_trip" (trip_id);

---validation test
-- Test Name: FK Check (trip_id: 5555 does not exist in dim_trip)
-- EXPECTED ERROR: ERROR: insert or update on table "fact_transit" 
-----violates foreign key constraint "fk_fact_trip" | Result: successful
INSERT INTO "gold.fact_transit" (route_id, trip_id, trip_stop_sequence_id)
VALUES (74750, 5555, 99999);

-- 7. Link fact_transit to dim_stop (using trip_stop_sequence_id)
ALTER TABLE "gold.fact_transit"
ADD CONSTRAINT fk_fact_stop
FOREIGN KEY (trip_stop_sequence_id) REFERENCES "gold.dim_stop" (trip_stop_sequence_id);

---validation test
-- Test Name: FK Check (trip_stop_sequence_id: 0 does not exist in dim_stop)
-- EXPECTED ERROR: ERROR: insert or update on table "fact_transit" 
----violates foreign key constraint "fk_fact_stop" | Result: successful
INSERT INTO "gold.fact_transit" (route_id, trip_stop_sequence_id)
VALUES (74750, 0);

--validating row count---
---Result: 1051045 : correct
select count(*) from "gold.fact_transit"

-- Checking for table view
SELECT * FROM "gold.fact_transit" limit 5;