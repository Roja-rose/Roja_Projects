SET search_path TO gold, public;
CREATE TABLE "gold.validation_tracking" (
    -- Primary Key: Unique identifier for each validation entry
    validation_id SERIAL PRIMARY KEY,

    -- Test details: 1. Test Name
    test_name VARCHAR(100) NOT NULL,
    
    -- Test details: 2. Description
    description TEXT,

    -- Execution details: 3. Validation Date
    validation_date DATE NOT NULL DEFAULT CURRENT_DATE,
    
    -- Result: 4. Outcome
    outcome VARCHAR(15) NOT NULL 
        CHECK (outcome IN ('Pass', 'Fail', 'Skipped', 'In Progress'))
);

-- Add a comment for documentation
COMMENT ON TABLE "gold.validation_tracking" IS 'Simplified table for tracking data quality and KPI validation test results in the GOLD schema.';

-- Add indexes for performance on frequently queried columns
CREATE INDEX idx_validation_date ON "gold.validation_tracking" (validation_date);
CREATE INDEX idx_test_name ON "gold.validation_tracking" (test_name);


-- Check 1A: route_id integrity
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) VALUES (
    'RI Check: route_id to Dim',
    'Validate that route_id in "gold.fact_transit" exists in the "dim_route" table.',
    '2025-10-23',
    'Pass' 
);

-- Check 1B: trip_id integrity
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) VALUES (
    'RI Check: trip_id to Dim',
    'Validate that trip_id in "gold.fact_transit" exists in the "dim_trip" table.',
    '2025-10-23',
    'Pass'
);

-- Check 1C: trip_stop_sequence_id integrity
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) VALUES (
    'RI Check: trip_stop_sequence_id to Dim',
    'Validate that trip_stop_sequence_id in "gold"."fact_transit" exists in its respective dimension.',
    '2025-10-23',
    'Pass'
);

-- 2. RELATIONSHIP CARDINALITY (Granular checks for four separate relationships)
-- Check 2A: dim_route (1) to fact_transit (Many)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) VALUES (
    'Cardinality Check: dim_route -> fact_transit',
    'Validate 1:M relationship between "dim_route" (PK) and "fact_transit" (FK) based on route_id.',
    '2025-10-23',
    'Pass' 
);

-- Check 2B: dim_trip (1) to fact_transit (Many)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) VALUES (
    'Cardinality Check: dim_trip -> fact_transit',
    'Validate 1:M relationship between "dim_trip" (PK) and "fact_transit" (FK) based on trip_id.',
    '2025-10-23',
    'Pass' 
);

-- Check 2C: dim_stop (1) to fact_transit (Many)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) VALUES (
    'Cardinality Check: dim_stop -> fact_transit',
    'Validate 1:M relationship between "dim_stop" (PK) and "fact_transit" (FK) based on stop_id.',
    '2025-10-23',
    'Pass'
);

-- Check 2D: dim_stop_description (1) to dim_stop (Many)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) VALUES (
    'Cardinality Check: dim_stop_description -> dim_stop',
    'Validate 1:M relationship between two dimension tables.',
    '2025-10-23',
    'Pass'
);


-- 3. KPI Logic Validation (Checks for ALL requested derived metrics)
-- This confirms the calculation logic itself is correct against known sample values.

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: trips_per_day', 'Verify trips_per_day calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: riders_per_hour', 'Verify riders_per_hour calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: riders_per_trip', 'Verify riders_per_trip calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: operational_cost_per_rider', 'Verify operational_cost_per_rider calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: operational_cost_per_day', 'Verify operational_cost_per_day calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: trip_duration', 'Verify trip_duration calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: route_duration', 'Verify route_duration calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: load_factor_per_trip', 'Verify load_factor_per_trip calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: service_span', 'Verify service_span calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: off_peak_trip_ratio', 'Verify off_peak_trip_ratio calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: trips_on_peak', 'Verify trips_on_peak calculation against sample data.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('KPI Logic: trips_off_peak', 'Verify trips_off_peak calculation against sample data.', '2025-10-23', 'Pass');


-- 4. Range/Consistency Check (Checks for ALL requested derived metrics)
-- This confirms all numeric KPIs fall within logical and operational bounds (e.g., non-negative, valid ratio).

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('Range Check: trips_per_day', 'Ensure trips_per_day is a positive integer (> 0).', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('Range Check: riders_per_hour', 'Ensure riders_per_hour is non-negative and realistic.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('Range Check: operational_cost (All)', 'Ensure all cost metrics are non-negative (>= 0).', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('Range Check: trip_duration', 'Ensure trip_duration is positive and within reasonable limits.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('Range Check: route_duration', 'Ensure route_duration is positive and within reasonable limits.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('Range Check: load_factor_per_trip', 'Ensure load_factor_per_trip is a valid ratio (0 < value <= 1).', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('Range Check: service_span', 'Ensure service_span is non-negative.', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('Range Check: off_peak_trip_ratio', 'Ensure off_peak_trip_ratio is a valid ratio (0 < value <= 1).', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('Range Check: trips_on_peak', 'Ensure trips_on_peak is a non-negative integer (>= 0).', '2025-10-23', 'Pass');

INSERT INTO "gold.validation_tracking" (test_name, description, validation_date, outcome) 
VALUES ('Range Check: trips_off_peak', 'Ensure trips_off_peak is a non-negative integer (>= 0).', '2025-10-23', 'Pass');

-- =================================================================================================
--5 --
-- AGGREGATION ACCURACY VALIDATION TEST
-- =================================================================================================


-- 1. Data Integrity: Missing Critical Data (PK/Cost)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
)
VALUES (
    '1. Data Integrity: Missing Critical Data (PK/Cost)',
    'Validate NULLs in essential key fields (trip_id) and core cost metrics (operational_cost_per_day, operational_cost_per_rider',
    CURRENT_DATE,
    'Pass' -- <-- Changed from 'PASS' to 'Pass'
);

-- 2. Data Integrity: Negative Operational Cost
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
)
VALUES (
    '2. Data Integrity: Negative Operational Cost',
    'Validate no cost-related fields contain values less than zero.',
    CURRENT_DATE,
    'Pass' -- <-- CORRECTED: Change from 'PASS' to 'Pass'
);

-- 3. Data Integrity: Missing Route Link
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
)
VALUES (
    '3. Data Integrity: Missing Route Link',
    'Ensure all operational records are tied to a non-NULL route_id.',
    CURRENT_DATE,
    'Pass' -- <-- CORRECTED: Change from 'PASS' to 'Pass'
);

-- 4. Data Range: Unreasonable Route Duration
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
)
VALUES (
    '4. Data Range: Unreasonable Route Duration',
    'Ensure route_duration is within a reasonable operating range (0 to 24 hours).',
    CURRENT_DATE,
    'Pass' -- Corrected: Changed from 'PASS' to 'Pass'
);

-- 5. Aggregation Accuracy (Trip Duration Reconciliation)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) 
VALUES (
    '5. Agg Accuracy: Trip Duration Reconciliation Mismatch (Fact vs Dim)',
    'Validate ft.trip_duration (in HOURS) against the derived trip duration from dim_stop (tolerance 0.01 hours).',
    CURRENT_DATE,
    'Pass' -- Corrected: Changed from 'PASS' to 'Pass'
);

-- 6. Aggregation Accuracy (Internal Trip Sum Consistency)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) 
VALUES (
    '6. Agg Accuracy: Trip Sum Consistency Mismatch (Peak + Off-Peak)',
    'Validate trips_per_day equals the sum of trips_on_peak and trips_off_peak.',
    CURRENT_DATE,
    'Pass' -- Corrected: Changed from 'PASS' to 'Pass'
);

-- 7. Aggregation Accuracy (Cost Derivation Consistency)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) 
VALUES (
    '7. Agg Accuracy: Cost Derivation Mismatch (Cost/Rider * Riders)',
    'Validate Cost/Day = (Cost/Rider * Riders/Day) within 0.01 tolerance.',
    CURRENT_DATE,
    'Pass' -- Corrected: Changed from 'PASS' to 'Pass'
);

-- 8. Aggregation Accuracy (Ridership Consistency: Per Hour Derivation)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) 
VALUES (
    '8. Agg Accuracy: Ridership Derivation Mismatch (Riders/Day / Hours/Day)',
    'Validate riders_per_hour = (riders_per_day / hours_per_day) with a tolerance of 1.',
    CURRENT_DATE,
    'Pass' -- Corrected: Changed from 'PASS' to 'Pass'
);

-- 9. Aggregation Accuracy (Load Factor Consistency at Trip Level)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) 
VALUES (
    '9. Agg Accuracy: Inconsistent Load Factor within Trip',
    'Check that the load_factor_per_trip is consistent for all records belonging to the same trip_id.',
    CURRENT_DATE,
    'Pass' -- Corrected: Changed from 'PASS' to 'Pass'
);

-- 10. Aggregation Accuracy (Ridership Per Trip Derivation)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) 
VALUES (
    '10. Agg Accuracy: Ridership Derivation Mismatch (Riders/Day / Trips/Day)',
    'Validate riders_per_trip = (riders_per_day / trips_per_day) with a tolerance of 1.',
    CURRENT_DATE,
    'Pass' -- Corrected: Changed from 'PASS' to 'Pass'
);
-- 11. Aggregation Accuracy (Off-Peak Ratio Derivation)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) 
VALUES (
    '11. Agg Accuracy: Off-Peak Ratio Derivation Mismatch',
    'Validate off_peak_trip_ratio equals (trips_off_peak / total_trips) within a 0.000001 tolerance.',
    CURRENT_DATE,
    'Pass' -- Corrected: Changed from 'PASS' to 'Pass'
);
-- 12. Aggregation Accuracy (Kilometres Per Day Consistency)
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) 
VALUES (
    '12. Agg Accuracy: Inconsistent Kilometres Per Day within Route',
    'Validate kilometres_per_day is consistent across all records for the same route_id.',
    CURRENT_DATE,
    'Pass' -- Corrected: Changed from 'PASS' to 'Pass'
);

-- 6. Final Record Count
INSERT INTO "gold.validation_tracking" (
    test_name,
    description,
    validation_date,
    outcome
) VALUES (
    'Final Record Count',
    'Confirm final fact and dimension tables contain expected number of records.',
    '2025-10-23',
    'Pass'
);

SELECT * FROM "gold.validation_tracking";