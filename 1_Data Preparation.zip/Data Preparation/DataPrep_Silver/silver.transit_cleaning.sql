SET search_path TO silver, public;

-- 1 --
-- Checking for data info
select * from "silver.transit_clean";

-- 2 -- 
-- Checking for table info.
-- Result. 207 rows
SELECT COUNT(*) FROM "silver.transit_clean";

-- 3 --
-- Removing columns
ALTER TABLE "silver.transit_clean" DROP COLUMN "Route_Long_Name";
ALTER TABLE "silver.transit_clean" DROP COLUMN "Vehicles Overnigth";

-- 4 --
-- Renaming columns
ALTER TABLE "silver.transit_clean" RENAME COLUMN "Route" to route_name;
ALTER TABLE "silver.transit_clean" RENAME COLUMN "Hours per Weekday" to hours_per_day;
ALTER TABLE "silver.transit_clean" RENAME COLUMN "Customer per Weekday" to customer_per_day;
ALTER TABLE "silver.transit_clean" RENAME COLUMN "Kilometres per Weekday" to kilometres_per_day;
ALTER TABLE "silver.transit_clean" RENAME COLUMN "Vehicles in AM Peak" to vehicle_am_peak;
ALTER TABLE "silver.transit_clean" RENAME COLUMN "Vehicles in PM Peak" to vehicle_pm_peak;

-- Checking for row count
-- Result. 207 rows
SELECT COUNT(*) FROM "silver.transit_clean";


-- 5 --
-- Validate numerical ranges 
-- Checking for negative values in numerical columns
-- Result. No negative values.

SELECT *
FROM "silver.transit_clean"
WHERE customer_per_day < 0
   OR hours_per_day < 0
   OR kilometres_per_day < 0
   OR vehicle_am_peak < 0
   OR vehicle_pm_peak < 0;

-- Checking for row count
-- Result. 207 rows
SELECT COUNT(*) FROM "silver.transit_clean";

-- 6 --
-- Checking for duplicates in route_name column
-- Result. There are no duplicates.
SELECT route_name,
    COUNT(route_name) AS NumberOfDuplicates
FROM "silver.transit_clean"
GROUP BY route_name
HAVING COUNT(route_name) > 1;

-- Checking for row count
-- Result. 207 rows
SELECT COUNT(*) FROM "silver.transit_clean";

-- 7 --
-- Checking for missing values
SELECT
    COUNT(*) AS total_rows,
    COUNT(CASE WHEN customer_per_day IS NULL THEN 1 END) AS missing_customer_per_day,
    COUNT(CASE WHEN hours_per_day IS NULL THEN 1 END) AS missing_hours_per_day,
    COUNT(CASE WHEN kilometres_per_day IS NULL THEN 1 END) AS missing_kilometres_per_day,
    COUNT(CASE WHEN vehicle_am_peak IS NULL THEN 1 END) AS missing_vehicle_am_peak,
    COUNT(CASE WHEN vehicle_pm_peak IS NULL THEN 1 END) AS missing_vehicle_pm_peak
FROM "silver.transit_clean";

-- Checking for row count
-- Result. 207 rows
SELECT COUNT(*) FROM "silver.transit_clean";

-- 8 --
-- Displaying missing values
-- Result. There are null values in vehicle_am_peak column related to route_name from 300 to 396. 
-- These routes are from Blue Night Network (300-series routes)
-- They have a very specific schedule:typically from 1:30 a.m. to the start of subway service (around 5:30 a.m. or 6:00 a.m.).
SELECT route_name, vehicle_am_peak FROM "silver.transit_clean" WHERE "vehicle_am_peak" is null;

-- 9 --
-- Handling missing values in vehicle_am_peak.
-- 300-series routes run from 1.30 and finish between 5.30 - 6.00. Morning peak hours start at 6.00 am. 
-- We replace null values in vehicle_am_peak for 300-series routes will '0' what will represent that there is no vehicle from Blue Nigth route at morning peak hours

UPDATE "silver.transit_clean"
SET 
    vehicle_am_peak = 0
WHERE 
    vehicle_am_peak IS NULL;
	
-- Checking for row count
-- Result. 207 rows
SELECT COUNT(*) FROM "silver.transit_clean";

-- 10 --
-- Checking again for missing values
-- Result. No missing values 
SELECT
    COUNT(*) AS total_rows,
    COUNT(CASE WHEN customer_per_day IS NULL THEN 1 END) AS missing_customer_per_day,
    COUNT(CASE WHEN hours_per_day IS NULL THEN 1 END) AS missing_hours_per_day,
    COUNT(CASE WHEN kilometres_per_day IS NULL THEN 1 END) AS missing_kilometres_per_day,
    COUNT(CASE WHEN vehicle_am_peak IS NULL THEN 1 END) AS missing_vehicle_am_peak,
    COUNT(CASE WHEN vehicle_pm_peak IS NULL THEN 1 END) AS missing_vehicle_pm_peak
FROM "silver.transit_clean";

-- 11 --
---Removing rows that are not related to bus using route_name from filtered route table
DELETE FROM "silver.transit_clean" t
WHERE t.route_name NOT IN (
    SELECT r.route_name
    FROM "silver.route_clean" r
);

--- 12--
-- Checking for row count before filtering.
SELECT COUNT(*) FROM "silver.transit_clean";

-- 13 --
---Validating if the removal step kept only matching route_names.
---Result: All remaining route_names should exist in the silver.route_clean table.
SELECT
    COUNT(CASE WHEN r.route_name IS NULL THEN 1 END) AS unmatched_routes_in_transit,
    COUNT(*) AS total_transit_rows
FROM "silver.transit_clean" t
LEFT JOIN "silver.route_clean" r ON t.route_name = r.route_name
WHERE r.route_name IS NULL;
-- A successful filter will return 0 for unmatched_routes_in_transit.

-- 13 --
---Validating if the removal step kept only matching route_names by checking for non-existence.
---A successful filter will return 0 for unmatched_routes_in_transit.
SELECT
    COUNT(*) AS unmatched_routes_in_transit
FROM "silver.transit_clean" t
WHERE NOT EXISTS (
    SELECT 1
    FROM "silver.route_clean" r
    WHERE r.route_name = t.route_name
);

-- 14 -- 
-- Adding a route_id column from silver.route_id where route_names from both tables match
ALTER TABLE "silver.transit_clean"
ADD COLUMN route_id INTEGER;

UPDATE "silver.transit_clean" AS t
SET 
    route_id = r.route_id
FROM 
    "silver.route_clean" AS r
WHERE 
    CAST(t.route_name AS TEXT) = CAST(r.route_name AS TEXT);


-- Checking for row count
-- Result. 189 rows
SELECT COUNT(*) FROM "silver.transit_clean";

--- 12--
-- Checking for row count before filtering.
SELECT * FROM "silver.transit_clean" limit 5;	



-- 14 --
-- Verification. Check a few routes to ensure the assigned ID 
-- matches the ID in the lookup table (silver.route_clean).
SELECT
    t.route_name AS transit_route_name,
    t.route_id AS assigned_route_id,
    -- Scalar subquery to find the expected ID from the route_clean table
    (
        SELECT r.route_id
        FROM "silver.route_clean" AS r
        WHERE
            CAST(r.route_name AS TEXT) = CAST(t.route_name AS TEXT)
    ) AS expected_route_id
FROM "silver.transit_clean" AS t
WHERE
    t.route_id IS NOT NULL -- Only check successfully matched routes
LIMIT 10;


-- Checking for row count for silver transit clean with route id added
-- Result. 189 rows
SELECT COUNT(*) FROM "silver.transit_clean";

-- 14 --
-- Verification. Checkin if route id us added correctly to transit table
---Check a few routes to ensure the assigned ID 
-- matches the ID in the lookup table (silver.route_clean).
SELECT
    t.route_name AS transit_route_name,
    t.route_id AS assigned_route_id,
    -- Scalar subquery to find the expected ID from the route_clean table
    (
        SELECT r.route_id
        FROM "silver.route_clean" AS r
        WHERE
            CAST(r.route_name AS TEXT) = CAST(t.route_name AS TEXT)
    ) AS expected_route_id
FROM "silver.transit_clean" AS t
WHERE
    t.route_id IS NOT NULL -- Only check successfully matched routes
LIMIT 10;



-- Adding a trip_id from silver.trip_clean into silver.transit_clean by creating a new table.
CREATE TABLE "silver.transit_trips" AS
SELECT
    t.route_name,
    t.customer_per_day,
    t.hours_per_day,
    t.kilometres_per_day,
    t.vehicle_am_peak,
    t.vehicle_pm_peak,
    t.route_id,     -- This column is duplicated for every trip
    r.trip_id       -- All trip_id records are included
FROM
    "silver.transit_clean" AS t, -- First table (implicitly joined)
    "silver.trip_clean" AS r     -- Second table (implicitly joined)
WHERE
    t.route_id = r.route_id; -- The linking condition

select * from "silver.transit_trips" limit 5;	

-- Checking for row count
-- Result. 32261 rows
SELECT COUNT(*) FROM "silver.transit_trips";

-- Verification Check: Query the new permanent table to confirm the row duplication.
SELECT
    route_id,
    trip_id,
    customer_per_day
FROM "silver.transit_trips" LIMIT 15;

-- Verification. Route Match Validation
-- Step 1b:
-- This check compares the unique number of routes in the original table 
-- against the number of unique routes that successfully joined the trips table.
-- If the counts are equal, all original routes found a match.

SELECT
    COUNT(DISTINCT route_id) AS original_unique_routes
FROM 
    "silver.transit_clean";

-- Step 2b: Count unique routes in the newly created, expanded table.
SELECT
    COUNT(DISTINCT route_id) AS joined_unique_routes
FROM 
    "silver.transit_trips";

---Checking if necessary columns are present
select * from "silver.transit_trips" limit 5;

-- Checking for row count after addition
-- Result. 32261 rows
SELECT COUNT(*) FROM "silver.transit_trips";

-- Adding a trip_stop_sequence_id column to the silver.transit_trips_stops table
DROP TABLE IF EXISTS "silver.transit_trips";

CREATE TABLE "silver.transit_trips" AS
SELECT
    t.route_name,
    t.customer_per_day,
    t.hours_per_day,
    t.kilometres_per_day,
    t.vehicle_am_peak,
    t.vehicle_pm_peak,
    t.route_id, 
    -- 1. Selects the trip_id. This name is not ambiguous.
    r.trip_id,
    -- 2. FIX: The column name is correct (s.trip_stop_sequence_id), 
    --    and we do not need a redundant alias (AS trip_stop_sequence_id).
    s.trip_stop_sequence_id 
FROM
    "silver.transit_clean" AS t, -- 1. Base Transit Data (Route Level)
    "silver.trip_clean" AS r,     -- 2. Trip Data
    "silver.stop_clean" AS s      -- 3. Stop Data
WHERE
    t.route_id = r.route_id   -- Link 1: Match Route to Trip (INNER JOIN)
    AND r.trip_id = s.trip_id;  -- Link 2: Match Trip to Stop (INNER JOIN)

-- VERIFICATION CHECK: Confirm the creation and the resulting count.
---Result: 1051045
SELECT COUNT(*) AS total_rows_in_new_table FROM "silver.transit_trips";
---Result: 189 same as before adding trip_stop_seq id
SELECT COUNT(DISTINCT route_id) AS unique_routes_in_new_table FROM "silver.transit_trips";

-- Verification. Route Match Validation
-- Step 1b:
-- This check compares the unique number of routes in the original table 
-- against the number of unique routes that successfully joined the trips table.
-- If the counts are equal, all original routes found a match.

SELECT
    COUNT(DISTINCT route_id) AS original_unique_routes
FROM 
    "silver.transit_clean";

-- Step 2b: Count unique routes in the newly created, expanded table.
SELECT
    COUNT(DISTINCT route_id) AS joined_unique_routes
FROM 
    "silver.transit_trips";

----Checking if necessary columns are present as per our erd
----Yes, table has necessary columns
select * from "silver.transit_trips" limit 5;

----Checking if necessary columns are present after removing route_name column
----Yes, table has necessary columns
select * from "silver.transit_trips" limit 5;


SELECT
    -- Count of NULL values in 'route_name' (should be 0 if clean)
    COUNT(CASE WHEN route_name IS NULL THEN 1 END) AS null_route_name_count,
    
    -- Count of NULL values in 'riders_per_day'
    COUNT(CASE WHEN riders_per_day IS NULL THEN 1 END) AS null_riders_per_day_count,
    
    -- Count of NULL values in 'hours_per_day'
    COUNT(CASE WHEN hours_per_day IS NULL THEN 1 END) AS null_hours_per_day_count,
    
    -- Count of NULL values in 'kilometres_per_day'
    COUNT(CASE WHEN kilometres_per_day IS NULL THEN 1 END) AS null_kilometres_per_day_count,
    
    -- Count of NULL values in 'route_id' (a primary key candidate, must be 0)
    COUNT(CASE WHEN route_id IS NULL THEN 1 END) AS null_route_id_count
FROM
    "silver.transit_trips";




-- Checking for negative values in silver.transit_trips
SELECT
    -- Count of negative riders
    COUNT(CASE WHEN riders_per_day < 0 THEN 1 END) AS negative_riders_count,

    -- Count of negative hours
    COUNT(CASE WHEN hours_per_day < 0 THEN 1 END) AS negative_hours_count,

    -- Count of negative kilometers
    COUNT(CASE WHEN kilometres_per_day < 0 THEN 1 END) AS negative_kilometres_count,

    -- Count of negative AM peak vehicles
    COUNT(CASE WHEN vehicle_am_peak < 0 THEN 1 END) AS negative_am_peak_count,

    -- Count of negative PM peak vehicles
    COUNT(CASE WHEN vehicle_pm_peak < 0 THEN 1 END) AS negative_pm_peak_count
FROM
    "silver.transit_trips";


-- Removing route_name column
ALTER TABLE "silver.transit_trips" DROP COLUMN "route_name";


----Checking if necessary columns are present after removing route_name column
----Yes, table has necessary columns
select * from "silver.transit_trips" limit 5;

---Changing table name for easy identification
ALTER TABLE "silver.transit_trips" 
RENAME TO "silver.transit_final_clean";



-- Checking for missing values in silver.transit_final_clean
SELECT
    
    -- Count of NULL values in 'riders_per_day'
    COUNT(CASE WHEN riders_per_day IS NULL THEN 1 END) AS null_riders_per_day_count,
    
    -- Count of NULL values in 'hours_per_day'
    COUNT(CASE WHEN hours_per_day IS NULL THEN 1 END) AS null_hours_per_day_count,
    
    -- Count of NULL values in 'kilometres_per_day'
    COUNT(CASE WHEN kilometres_per_day IS NULL THEN 1 END) AS null_kilometres_per_day_count,
    
    -- Count of NULL values in 'route_id' (a primary key candidate, must be 0)
    COUNT(CASE WHEN route_id IS NULL THEN 1 END) AS null_route_id_count
FROM
    "silver.transit_final_clean";




--Checking for negative values in silver.transit_final_clean table
SELECT
    -- IDs (should be positive)
    COUNT(CASE WHEN route_id < 0 THEN 1 END) AS negative_route_id_count,
    COUNT(CASE WHEN trip_id < 0 THEN 1 END) AS negative_trip_id_count,
    COUNT(CASE WHEN trip_stop_sequence_id < 0 THEN 1 END) AS negative_stop_id_count,
    
    -- Counts and Measurements (should be non-negative)
    COUNT(CASE WHEN riders_per_day < 0 THEN 1 END) AS negative_riders_count,
    COUNT(CASE WHEN hours_per_day < 0 THEN 1 END) AS negative_hours_count,
    COUNT(CASE WHEN kilometres_per_day < 0 THEN 1 END) AS negative_kilometres_count,
    
    -- Vehicle Peaks (must be non-negative)
    COUNT(CASE WHEN vehicle_am_peak < 0 THEN 1 END) AS negative_vehicle_am_peak_count,
    COUNT(CASE WHEN vehicle_pm_peak < 0 THEN 1 END) AS negative_vehicle_pm_peak_count
FROM
    "silver.transit_final_clean";




select * from "silver.transit_final_clean" limit 5;
select count(*) from "silver.transit_final_clean";

ALTER TABLE "silver.transit_final_clean" RENAME COLUMN customer_per_day to riders_per_day;

select * from "silver.transit_final_clean" limit 5;
select count(*) from "silver.transit_final_clean";
