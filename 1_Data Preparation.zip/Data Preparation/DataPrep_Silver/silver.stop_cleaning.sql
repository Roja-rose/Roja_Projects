SET search_path TO silver, public;
SELECT * FROM "silver.stop_clean" limit 5;

SELECT COUNT(*) FROM "silver.stop_clean"

SET search_path TO silver, public;
SELECT table_schema, table_name
FROM information_schema.tables
WHERE table_schema = 'silver';
-- 1 -- 
-- Checking for table info.
SELECT * FROM "silver.stop_clean" LIMIT 5;

-- 2 -- 
-- Checking for table info.
-- Result is 4310022 rows
SELECT COUNT(*) FROM "silver.stop_clean";

-- 3 --
-- Removing columns columns
-- Columns removed sucessfully
ALTER TABLE "silver.stop_clean" DROP COLUMN pickup_type;
ALTER TABLE "silver.stop_clean" DROP COLUMN drop_off_type;
ALTER TABLE "silver.stop_clean" DROP COLUMN shape_dist_traveled;
ALTER TABLE "silver.stop_clean" DROP COLUMN stop_headsign;
SELECT * FROM "silver.stop_clean" LIMIT 5;

-- 4 --
-- Checking Total number of records after dropping and renaming columns
---Result: 4310022 same as raw file
SELECT COUNT(*) FROM "silver.stop_clean";

-- 5 --
-- Validating datatype for all columns.
--Result: stopping_time was changed to varchar for importing, will be reviewing
SELECT * FROM "silver.stop_clean" LIMIT 5;

---changing datatype of stopping_time to time
---Result: Cannot be changed as the time datatype cannot take time greater than 24hrs
ALTER TABLE "silver.stop_clean"
ALTER COLUMN stopping_time TYPE TIME
USING stopping_time::TIME;

---counting number of time values are out of range
---Result: more than 4 lakhs records have a time range not supported by time datatype
SELECT
    COUNT(*)
FROM
    "silver.stop_clean"
WHERE
    -- Use SPLIT_PART to get the hour (the first part of the string before the first ':')
    -- This handles both '25:00:00' and '5:00:00' correctly.
    CAST(SPLIT_PART(arrival_time, ':', 1) AS INTEGER) >= 24
    OR CAST(SPLIT_PART(departure_time, ':', 1) AS INTEGER) >= 24;

-- 6 --
-- Checking for NULL values in all columns
---No null values present
select * from "silver.stop_clean" where trip_id is null
or arrival_time is null or stop_id is null or departure_time is null
or stop_sequence is null;

--7--
-- checking for duplicates
-- Checking for duplicates in stop_id column. If there are duplicates. Stop_id column can not be a primary key.
-- Result. Stop_id is duplicated. Can not be a primary key in a stop table.
SELECT
    stop_id,
    COUNT(stop_id) AS Duplicate_Count
FROM
    "silver.stop_clean"
GROUP BY
    stop_id
HAVING
    COUNT(stop_id) > 1;

---8--
-- Checking if the combination of trip_id and stop_id is repeated. 
-- If it the combination is repeated we can not create composite key stop_id + trip_id
-- Result. The combination is repeated. 
SELECT
    trip_id,
    stop_id,
    COUNT(*) AS Duplicate_Count
FROM
    "silver.stop_clean"
GROUP BY
    trip_id,
    stop_id
HAVING
    COUNT(*) > 1;

--9---
-- Checking if the combination of trip_id and stop_sequene is repeated. 
-- If it the combination is repeated we can not create composite key trip_id + stop_sequence.
-- Result. The combination is NOT repeated. so can be a composite key
SELECT
    trip_id,
    stop_sequence,
    COUNT(*) AS Duplicate_Count
FROM
    "silver.stop_clean"
GROUP BY
    trip_id,
    stop_sequence
HAVING
    COUNT(*) > 1;

-- ----
-- -- assign a sequential, unique integer to every row, including existing ones
-- ---, and automatically applies a NOT NULL constraint.
-- ALTER TABLE "silver.stop_clean"
-- ADD COLUMN trip_stop_sequence_id INT GENERATED ALWAYS AS IDENTITY;

-- --  --
-- -- Set the New Column as the Primary Key
-- --trip_stop_sequence_id is the pk

-- ALTER TABLE "silver.stop_clean"
-- ADD CONSTRAINT trip_stop_sequence_id_pk
-- PRIMARY KEY (trip_stop_sequence_id);

--Checking if all the necessary columns are present and matches erd
--Result. yes and matches erd
SELECT * FROM "silver.stop_clean" LIMIT 5;

--Checking if the number of rows changed during cleaning
--Result. no.of rows remains the same
SELECT COUNT(*) FROM "silver.stop_clean";

--10--
---Removing rows that are not related to bus using trip id from filtered trip table
DELETE FROM "silver.stop_clean" t
WHERE t.trip_id NOT IN (
    SELECT Distinct r.trip_id
    FROM "silver.trip_clean" r
);

---11--
---validating if filtering specific to bus data
--Result: returns no rows, all stops belong to bus trips.
SELECT trip_id
FROM "silver.stop_clean"
EXCEPT
SELECT trip_id
FROM "silver.trip_clean";

---12--
-- Checking for row count after filtering.
-- Result is 1056103 rows
SELECT COUNT(*) FROM "silver.stop_clean";


--13---
-- assign a sequential, unique integer to every row, including existing ones
---, and automatically applies a NOT NULL constraint, which will used as pk
ALTER TABLE "silver.stop_clean"
ADD COLUMN trip_stop_sequence_id INT GENERATED ALWAYS AS IDENTITY;

----checking if id is created for alll records
--Yes, total row count matches
select max(trip_stop_sequence_id) from "silver.stop_clean" 

---13--
-- Checking for row count after filtering.
-- Result is 1056103 rows
SELECT COUNT(*) FROM "silver.stop_clean";

--Checking if all the necessary columns are present and matches erd
--Result. yes and matches erd
SELECT * FROM "silver.stop_clean" LIMIT 5;

--14---
---we are removing departure time, given that the difference between arrival and departure is 
-----negligible for the vast majority of records (around 1.5k)
ALTER TABLE "silver.stop_clean" DROP COLUMN departure_time;

--Renaming the arrival_time column to reflect its new purpose as the single time point
---as stopping_time
ALTER TABLE "silver.stop_clean" RENAME COLUMN arrival_time TO stopping_time;

--checking the table after remova and rename of columns
SELECT * FROM "silver.stop_clean" LIMIT 5;


-- As the stopping type is in varchar and cannot be converted to type as there out of range values
-- Adding a new INTEGER column (this will be the final, clean time column) for kpis calculation
ALTER TABLE "silver.stop_clean" ADD COLUMN stopping_time_sec INTEGER;

-- Populate the new column by converting the existing arrival_time (VARCHAR) to total seconds.
-- We use arrival_time as the chosen single time point.
UPDATE "silver.stop_clean"
SET
    stopping_time_sec =
        -- Hour * 3600
        CAST(SPLIT_PART(stopping_time, ':', 1) AS INTEGER) * 3600 +
        -- Minute * 60
        CAST(SPLIT_PART(stopping_time, ':', 2) AS INTEGER) * 60 +
        -- Second
        CAST(SPLIT_PART(stopping_time, ':', 3) AS INTEGER);



-- Checking for negative values in silver.stop_clean table
SELECT
    -- Check for negative IDs (which should be positive integers)
    COUNT(CASE WHEN trip_id < 0 THEN 1 END) AS negative_trip_id_count,
    COUNT(CASE WHEN stop_id < 0 THEN 1 END) AS negative_stop_id_count,

    -- Check for negative sequence numbers (must be positive)
    COUNT(CASE WHEN trip_stop_sequence_id < 0 THEN 1 END) AS negative_sequence_count,

    -- Check for negative time in seconds (time cannot be negative)
    COUNT(CASE WHEN stopping_time_sec < 0 THEN 1 END) AS negative_time_sec_count
FROM
    "silver.stop_clean";


-- Checking for row count after all the cleaning steps.
-- Result is 1056103 rows
SELECT COUNT(*) FROM "silver.stop_clean";

--Checking if all the necessary columns are present and matches erd
--Result. yes and matches erd
SELECT * FROM "silver.stop_clean" LIMIT 5;



