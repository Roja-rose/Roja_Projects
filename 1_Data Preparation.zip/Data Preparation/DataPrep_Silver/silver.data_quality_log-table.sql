SET search_path TO silver, public;

CREATE TABLE "silver.data_quality_log" (
    validation_id BIGSERIAL PRIMARY KEY,
    test_name TEXT NOT NULL,
    description TEXT,
    validation_date DATE NOT NULL DEFAULT CURRENT_DATE,
    dataset TEXT NOT NULL,
    outcome TEXT -- Stores 'Pass', 'Fail', or 'Warning'
);

WITH TestResults AS (
    -- Filters to relevant validation steps from audit log
    SELECT
        dataset,
        process_name,
        validation_result
    FROM
        "silver.audit_log"
    WHERE
        process_name NOT IN (
            'Initial Row Count',
            'Column Drop',
            'Final Row Count Confirmation',
            'Post-Alter Row Count Confirmation',
            'Structural Changes: Column Drops (Initial Set)',
            'Structural Changes: Column Drops',
            'Post-Population Data Check ',
            'Row Count Confirmation',
            'Table Recreation: Join Route-Trip-Stop (Final)'
        )
),
DatasetList AS (
    SELECT DISTINCT dataset FROM TestResults
)

INSERT INTO "silver.data_quality_log" (
    test_name,
    description,
    validation_date,
    dataset,
    outcome
)

-- 1. Schema Validation
SELECT
    'Schema Validation' AS test_name,
    'Ensure all expected columns and datatypes match data dictionary.' AS description,
    '2025-10-26'::DATE AS validation_date, -- STATIC DATE APPLIED HERE
    T.dataset,
    CASE
        WHEN EXISTS (
            SELECT 1 FROM TestResults R
            WHERE R.dataset = T.dataset
            AND R.process_name IN ('Datatype Validation', 'Final Schema Check', 'Structural Change: Rename Table')
            AND R.validation_result = 'Fail'
        ) THEN 'FAIL'
        ELSE 'PASS'
    END AS outcome
FROM DatasetList T

UNION ALL

-- 2. Uniqueness Check
SELECT
    'Uniqueness Check',
    'Confirm IDs (route_id, trip_id, stop_id) are unique and non-null.',
    '2025-10-26'::DATE, -- STATIC DATE APPLIED HERE
    T.dataset,
    CASE
        WHEN EXISTS (
            SELECT 1 FROM TestResults R
            WHERE R.dataset = T.dataset
            AND R.process_name LIKE 'Key Analysis:%Duplicates'
            AND R.validation_result IN ('Fail')
        ) THEN 'FAIL'
        WHEN EXISTS (
            SELECT 1 FROM TestResults R
            WHERE R.dataset = T.dataset
            AND R.process_name LIKE 'Key Analysis:%Duplicates'
            AND R.validation_result IN ('WARNING')
        ) THEN 'WARNING'
        ELSE 'PASS'
    END
FROM DatasetList T

UNION ALL

-- 3. Referential Integrity
SELECT
    'Referential Integrity',
    'Validate key relationships between routes, trips, and stops.',
    '2025-10-26'::DATE, -- STATIC DATE APPLIED HERE
    T.dataset,
    CASE
        WHEN EXISTS (
            SELECT 1 FROM TestResults R
            WHERE R.dataset = T.dataset
            AND R.process_name LIKE 'Validation: Unmatched Routes Check'
            AND R.validation_result IN ('Fail')
        ) THEN 'FAIL'
        ELSE 'PASS'
    END
FROM DatasetList T

UNION ALL

-- 4. Completeness (Null Value Checks)
SELECT
    'Completeness',
    'Ensure key columns are populated (Null Value Check).',
    '2025-10-26'::DATE, -- STATIC DATE APPLIED HERE
    T.dataset,
    CASE
        WHEN EXISTS (
            SELECT 1 FROM TestResults R
            WHERE R.dataset = T.dataset
            AND (R.process_name LIKE '%NULL Value Check%' OR R.process_name LIKE '%Missing Value Tally%')
            AND R.validation_result = 'Fail'
        ) THEN 'FAIL'
        ELSE 'PASS'
    END
FROM DatasetList T

UNION ALL

-- 5. Domain/Range Check (Negative Values, Out-of-Range Time)
SELECT
    'Domain/Range Check',
    'Verify numerical and categorical fields fall within expected limits.',
    '2025-10-26'::DATE, -- STATIC DATE APPLIED HERE
    T.dataset,
    CASE
        WHEN EXISTS (
            SELECT 1 FROM TestResults R
            WHERE R.dataset = T.dataset
            AND R.process_name IN ('Negative Value Check (route_length)', 'Negative Value Check (Numeric Columns)')
            AND R.validation_result = 'Fail'
        ) THEN 'FAIL'
        ELSE 'PASS'
    END
FROM DatasetList T

UNION ALL

-- 6. Time Format Validation
SELECT
    'Time Format Validation',
    'Confirm all time fields follow HH:MM:SS format and can be cast.',
    '2025-10-26'::DATE, -- STATIC DATE APPLIED HERE
    T.dataset,
    CASE
        WHEN EXISTS (
            SELECT 1 FROM TestResults R
            WHERE R.dataset = T.dataset
            AND R.process_name LIKE '%TIME Conversion Failure%'
            AND R.validation_result = 'Fail'
        ) THEN 'FAIL'
        ELSE 'PASS'
    END
FROM DatasetList T

UNION ALL

-- 7. Duplicate/Filtering Removal Check
SELECT
    'Duplicate/Filtering Removal Check',
    'Validate that identified duplicates/unwanted rows were correctly removed.',
    '2025-10-26'::DATE, -- STATIC DATE APPLIED HERE
    T.dataset,
    CASE
        WHEN EXISTS (
            SELECT 1 FROM TestResults R
            WHERE R.dataset = T.dataset
            AND (R.process_name LIKE 'Filter %' OR R.process_name LIKE 'Data Filtering:%')
            AND R.validation_result = 'Fail'
        ) THEN 'FAIL'
        ELSE 'PASS'
    END
FROM DatasetList T;

SELECT * FROM "silver.data_quality_log";