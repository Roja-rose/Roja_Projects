SET search_path TO silver, public;

-- 1 --
-- Checking for data info
select * from "silver.trip_clean" limit 5;

-- 2 -- 
-- Checking for table info.
-- Result. 130373 rows
SELECT COUNT(*) FROM "silver.trip_clean";

-- 3 --
-- Removing columns
ALTER TABLE "silver.trip_clean" DROP COLUMN trip_short_name;
ALTER TABLE "silver.trip_clean" DROP COLUMN direction_id;
ALTER TABLE "silver.trip_clean" DROP COLUMN block_id;
ALTER TABLE "silver.trip_clean" DROP COLUMN shape_id;
ALTER TABLE "silver.trip_clean" DROP COLUMN wheelchair_accessible;
ALTER TABLE "silver.trip_clean" DROP COLUMN bikes_allowed;

-- Checking for table info after removing columns.
-- Result. 130373 rows
SELECT COUNT(*) FROM "silver.trip_clean";

-- 4 --
-- Remove leading/trailing whitespace and standardizing casing 

UPDATE "silver.trip_clean" SET trip_headsign = UPPER(TRIM(trip_headsign));

-- Checking for data info
select * from "silver.trip_clean" limit 5;

-- Checking for table info.
-- Result. 130373 rows
SELECT COUNT(*) FROM "silver.trip_clean";

-- 5 --
-- Checking for missing values in dim_route table.
-- Result. No missing values.
SELECT *
FROM "silver.trip_clean"
WHERE "route_id" IS NULL             
   OR "trip_id" IS NULL
   OR "trip_headsign" IS NULL;

-- 6 --
-- Validating id format for route_id column
-- Result. There is no error.
ALTER TABLE "silver.trip_clean" ADD CONSTRAINT check_route_id_format
CHECK (CAST(route_id AS VARCHAR) ~ '^[0-9]{5}$');

-- Checking for data info
select * from "silver.trip_clean" limit 5;

-- Checking for table info.
-- Result. 130373 rows
SELECT COUNT(*) FROM "silver.trip_clean";

-- 7 --
-- Validating id format for trip_id column
-- Result. There is no error.
ALTER TABLE "silver.trip_clean" ADD CONSTRAINT check_trip_id_format
CHECK (CAST(trip_id AS VARCHAR) ~ '^[0-9]{8}$');

-- 8 --
-- Checking for duplicates in route_id column
-- Result. There are duplicates. Route_id can not be a primary key.
SELECT route_id,
    COUNT(route_id) AS NumberOfDuplicates
FROM "silver.trip_clean"
GROUP BY route_id
HAVING COUNT(route_id) > 1;

-- 9 --
-- Checking for duplicates in trip_id column
-- Result. No duplicates. Trip_id can be a primary key in silver.trip_clean table
SELECT trip_id,
    COUNT(trip_id) AS NumberOfDuplicates
FROM "silver.trip_clean"
GROUP BY trip_id
HAVING COUNT(trip_id) > 1;

-- Checking for table info.
-- Result. 130373 rows
SELECT COUNT(*) FROM "silver.trip_clean";

--10--
---Removing rows that are not related to bus using route id from filtered route table
DELETE FROM "silver.trip_clean" t
WHERE t.route_id NOT IN (
    SELECT r.route_id
    FROM "silver.route_clean" r
);

---11--
-- Checking for row count before filtering.
-- Result is 110801 rows
SELECT COUNT(*) FROM "silver.trip_clean";

--12---
---Validating if the removal step removed only rows not related to bus
-- SELECT DISTINCT r.route_type
-- FROM "silver.trip_clean" t
-- JOIN "silver.route_clean" r ON t.route_id = r.route_id;
---Validating without using join
---Result: all trips belong to routes that
---are still in the (filtered) silver.route_clean table → i.e., only bus routes.
SELECT t.route_id
FROM "silver.trip_clean" t
WHERE t.route_id NOT IN (
    SELECT r.route_id
    FROM "silver.route_clean" r
);

-- 13 --
-- Display all distict service_id

SELECT DISTINCT service_id
FROM "silver.trip_clean"
ORDER BY service_id;

-- 14 --
-- Removing trip_id which do not related to weekday trips (weekdsy trip = service_id = 1)

DELETE FROM "silver.trip_clean"
WHERE service_id != 1;

-- Checking for table info.
-- Result. 32604 rows
SELECT COUNT(*) FROM "silver.trip_clean";


-- 15 --
-- Removing columns
ALTER TABLE "silver.trip_clean" DROP COLUMN service_id;



--Checking for negative values in silver.trip_clean table
SELECT
    -- Check for negative route ID
    COUNT(CASE WHEN route_id < 0 THEN 1 END) AS negative_route_id_count,

    -- Check for negative trip ID
    COUNT(CASE WHEN trip_id < 0 THEN 1 END) AS negative_trip_id_count
FROM
    "silver.trip_clean";



-- Checking for table info.
-- Result. 32604 rows
SELECT COUNT(*) FROM "silver.trip_clean";

-- 16 --
-- Checking for data info
select * from "silver.trip_clean" limit 5;