SET search_path TO silver, public;

-- 1 --
-- Checking for data info
select * from "silver.route_clean" limit 5;

-- 2 -- 
-- Checking for table info.
-- Result. 221 rows
SELECT COUNT(*) FROM "silver.route_clean";


-- 3 --
-- Renaming columns
ALTER TABLE "silver.route_clean" RENAME COLUMN route_short_name to route_name;

--Checking for number of rows
-- Result. 221
SELECT COUNT(*) FROM "silver.route_clean";

-- 4 --
-- Removing columns
ALTER TABLE "silver.route_clean" DROP COLUMN agency_id;
ALTER TABLE "silver.route_clean" DROP COLUMN route_desc;
ALTER TABLE "silver.route_clean" DROP COLUMN route_url;
ALTER TABLE "silver.route_clean" DROP COLUMN route_color;
ALTER TABLE "silver.route_clean" DROP COLUMN route_text_color;

--Checking for number of rows
-- Result. 201
SELECT COUNT(*) FROM "silver.route_clean"

-- 5 --
-- Remove leading/trailing whitespace and standardizing casing 

UPDATE "route_long_name" SET route_long_name = UPPER(TRIM(route_long_name));

-- 6 --
-- Validate numerical ranges 
-- Checking for negative values in numerical column route_length column
-- Result. No negative values.

SELECT * FROM "silver.route_clean" WHERE route_length < 0;

-- 7 -- Checking for distinct values in bus_type column
SELECT DISTINCT bus_type FROM "silver.route_clean";

--8 -- Bringing inconsistent values into a single, uniform format.
UPDATE "silver.route_clean"
SET bus_type = 
    CASE
        WHEN UPPER(bus_type) LIKE '%ABUS%' THEN 'abus'
        WHEN UPPER(bus_type) LIKE '%BUS%' THEN 'bus'        
        ELSE UPPER(bus_type) 
    END;

SELECT DISTINCT bus_type FROM "silver.route_clean";

-- 9 --
-- Validating id format for route_id column
-- Result. There is no error.
ALTER TABLE "silver.route_clean" ADD CONSTRAINT check_route_id_format
CHECK (CAST(route_id AS VARCHAR) ~ '^[0-9]{5}$');


-- 10 --
-- Checking for duplicates in route_id column
-- Result. No duplicates.
SELECT route_id,
    COUNT(route_id) AS NumberOfDuplicates
FROM "silver.route_clean"
GROUP BY route_id
HAVING COUNT(route_id) > 1;


-- 10 --
-- Removing data related to streetcars and subway. 
-- Filtering by route_typy where 0= streetcar, 1= subway, 3= bus

DELETE FROM "silver.route_clean"
WHERE route_type IN (0, 1);



-- 12 --
-- Removing 7 seasonal or community buses with route_name (203, 400, 402, 403, 404, 405, 406)
-- They are not regular buses.
DELETE FROM "silver.route_clean"
WHERE route_name IN (203, 400, 402, 403, 404, 405, 406);

--13 --
--Checking for missing values in dim_route table.
-- Result. Null values are in the routes related to subway and streetcars. 

SELECT *
FROM "silver.route_clean"
WHERE "route_id" IS NULL             
   OR "route_name" IS NULL
   OR "route_long_name" IS NULL
   OR "route_type" IS NULL
   OR "route_length" IS NULL
   OR "bus_type" IS NULL;


--11 --
-- Creating a new column bus_capacity
ALTER TABLE dim_route ADD COLUMN bus_capacity INTEGER;

UPDATE dim_route
SET bus_capacity =
    CASE
        WHEN bus_type = 'Bus' THEN 51
        WHEN bus_type = 'ABus' THEN 77
        ELSE NULL 
    END;

-- Checking for data info
select * from "silver.route_clean" limit 5;


 
-- Checking for table info.
SELECT COUNT(*) FROM "silver.route_clean";

ALTER TABLE "silver.route_clean" DROP COLUMN route_length;

-- Checking for data info
select * from "silver.route_clean" limit 5;



-- Checking for table info.
-- Result. 194 rows
SELECT COUNT(*) FROM "silver.route_clean";

