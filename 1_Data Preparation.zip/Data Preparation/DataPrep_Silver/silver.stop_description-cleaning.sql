SET search_path TO silver, public;
SELECT table_schema, table_name
FROM information_schema.tables
WHERE table_schema = 'silver';
-- 1 -- 
-- Checking for table info.
SELECT * FROM "silver.stop_description_clean" LIMIT 5;

-- 2 -- 
-- Checking for table info.
-- Result is 9326 rows
SELECT COUNT(*) FROM "silver.stop_description_clean";

--3---
---Removing irrelevant columns for analysis
---Result: Successfully removed
ALTER TABLE "silver.stop_description_clean" DROP COLUMN stop_desc;
ALTER TABLE "silver.stop_description_clean"  DROP COLUMN zone_id;
ALTER TABLE "silver.stop_description_clean"  DROP COLUMN stop_url;
ALTER TABLE "silver.stop_description_clean"  DROP COLUMN location_type;
ALTER TABLE "silver.stop_description_clean"  DROP COLUMN parent_station;
ALTER TABLE "silver.stop_description_clean"  DROP COLUMN stop_timezone;
ALTER TABLE "silver.stop_description_clean"  DROP COLUMN wheelchair_boarding;
ALTER TABLE "silver.stop_description_clean"  DROP COLUMN stop_code;
--4--
--validating column removal step
SELECT * FROM "silver.stop_description_clean" LIMIT 5;

--5--
-- Checking for table info after removing cols
-- Result is 9326 rows
SELECT COUNT(*) FROM "silver.stop_description_clean";

-- 6 --
-- Validating datatype for all columns.
--datatypes are correct
SELECT * FROM "silver.stop_description_clean" LIMIT 5;

--7--
-- Checking for NULL values in all columns
---No null values present
select * from "silver.stop_description_clean" where stop_id is null
or stop_name is null 
or stop_lat is null or stop_lon is null;

-- --8--
-- -- checking for duplicates
-- -- Checking for duplicates in stop_id column. If there are duplicates. Stop_id column can not be a primary key.
-- -- Result. Stop_id is unique and can be used as pk.
-- SELECT
--     stop_id,
--     COUNT(stop_id) AS Duplicate_Count
-- FROM
--     "silver.stop_description_clean"
-- GROUP BY
--     stop_id
-- HAVING
--     COUNT(stop_id) > 1;

-- ---9--
--Checking if all the necessary columns are present after cleaning and matches erd
-- --Result. yes and matches erd
-- SELECT * FROM "silver.stop_description_clean" LIMIT 5;

-- --Checking if the number of rows changed after cleaning
-- --Result. no.of rows remains the same
-- SELECT COUNT(*) FROM "silver.stop_description_clean";

--10--
-- checking for duplicates
-- Checking for duplicates in stop_id column. If there are duplicates. Stop_id column can not be a primary key.
-- Result. Stop_id is not duplicated. Can be a primary key in a stop_description table 
SELECT
    stop_id,
    COUNT(stop_id) AS Duplicate_Count
FROM
    "silver.stop_description_clean"
GROUP BY
    stop_id
HAVING
    COUNT(stop_id) > 1;



--12---
--Removing rows that are not related to bus using trip id from filtered trip table
DELETE FROM "silver.stop_description_clean"
WHERE stop_id NOT IN (
    SELECT stop_id
    FROM "silver.stop_clean"
);

--13--
---validating if filtering is specific to bus data
--Result: returns no rows, all stops belong to bus trips.
SELECT COUNT(*) 
FROM "silver.stop_description_clean"
WHERE stop_id NOT IN (
    SELECT stop_id
    FROM "silver.stop_clean"
);




-- Checking for negative values in stop_id column in silver.stop_description table
SELECT
    -- Count records where stop_id (a key) is negative
    COUNT(CASE
        WHEN stop_id < 0 THEN 1
    END) AS negative_stop_id_count,

    -- Count records where Latitude is outside the valid range (-90 to 90)
    COUNT(CASE
        WHEN stop_lat IS NOT NULL AND (stop_lat < -90 OR stop_lat > 90) THEN 1
    END) AS invalid_latitude_count,

    -- Count records where Longitude is outside the valid range (-180 to 180)
    COUNT(CASE
        WHEN stop_lon IS NOT NULL AND (stop_lon < -180 OR stop_lon > 180) THEN 1
    END) AS invalid_longitude_count
FROM
    "silver.stop_description_clean";

---13--
--Checking if all the necessary columns are present after cleaning and matches erd
--Result. yes and matches erd
SELECT * FROM "silver.stop_description_clean" LIMIT 5;

--Checking if the number of rows changed after cleaning
--Result. no.of rows remains the same as checked with bus data
SELECT COUNT(*) FROM "silver.stop_description_clean";