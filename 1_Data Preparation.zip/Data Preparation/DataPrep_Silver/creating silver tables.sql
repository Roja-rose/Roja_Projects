-- Telling the session to look for objects in the current schema list
SET search_path TO bronze, silver, public; 

-- 1 --
-- Coping route_raw table from bronze schema into the silver schema
CREATE TABLE silver.route_clean
AS
SELECT *
FROM "bronze.route_raw";

-- Checking for table view
SELECT * FROM silver.route_clean limit 5;

-- 2 --
-- Coping stop_description_raw table from bronze schema into the silver schema
CREATE TABLE silver.stop_description_clean
AS
SELECT *
FROM "bronze.stop_description_raw";

-- Checking for table view
SELECT * FROM silver.stop_description_clean limit 5;

-- 3 --
-- Coping stop_raw table from bronze schema into the silver schema
CREATE TABLE silver.stop_clean
AS
SELECT *
FROM "bronze.stop_raw";

-- Checking for table view
SELECT * FROM silver.stop_clean limit 5

-- 4 --
-- Coping transit_raw table from bronze schema into the silver schema
CREATE TABLE silver.transit_clean
AS
SELECT *
FROM "bronze.transit_raw";

-- Checking for table view
SELECT * FROM silver.transit_clean limit 5;

-- 5 --
-- Coping stop_description_raw table from bronze schema into the silver schema
CREATE TABLE silver.trip_clean
AS
SELECT *
FROM "bronze.trip_raw";

-- Checking for table view
SELECT * FROM silver.trip_clean limit 5;
