SET search_path TO silver, public;

-- 1 -- Create the Process Audit Log Table

CREATE TABLE "silver.audit_log" (
    log_id BIGSERIAL PRIMARY KEY,
    dataset TEXT NOT NULL,
    process_name TEXT NOT NULL,
    row_count_before INTEGER,
    row_count_after INTEGER,
    validation_result TEXT,
    timestamp TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT now(),
    notes TEXT
);

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Initial Row Count', 221, 221, 'Pass', 'Initial row count before cleaning began.');


INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Column Rename', 221, 221, 'Pass', 'Renamed route_short_name to route_name.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Column Drop', 221, 221, 'Pass', 'Dropped agency_id, route_desc, route_url, route_color, route_text_color.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Data Standardization (TRIM/UPPER)', 221, 221, 'Pass', 'Applied UPPER(TRIM()) to route_long_name.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Negative Value Check (route_length)', 221, 221, 'Pass', 'Validation passed: No negative values found in route_length.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Standardize bus_type', 221, 221, 'Pass', 'Normalized bus_type column values (e.g., %BUS% to bus).');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Route ID Format Check', 221, 221, 'Pass', 'Added check_route_id_format constraint (5 digits).');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Route ID Duplicates Check', 221, 221, 'Pass', 'Validation passed: No duplicates found in route_id.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Filter Non-Bus (route_type 0, 1)', 221, 201, 'Pass', 'Removed 20 rows where route_type = 0 (Streetcar) or 1 (Subway).');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Filter Specialized Buses', 201, 194, 'Pass', 'Removed 7 specialized buses (203, 400-406) that are not regular service.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.route_clean', 'Null Value Check', 194, 194, 'Pass', 'No null values found in final, filtered columns.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.route_clean', 'Schema Change: Add bus_capacity Column', 194, 194, 'Pass', 'Column bus_capacity added. Added new INTEGER column bus_capacity to silver.route_clean.');


INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.route_clean', 'Feature Engineering: Populate bus_capacity', 194, 194, 'Pass', 'Column bus_capacity populated. Populated bus_capacity based on bus_type: bus=51, abus=77. Row count unchanged.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.route_clean', 'Post-Population Data Check ', 194, 194, 'Pass', 'Data visually inspected. Verified the first 5 rows to confirm bus_capacity was populated correctly based on bus_type.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.route_clean', 'Row Count Confirmation', 194, 194, 'Pass', 'Row count confirmed. Confirmed the final row count is 194, ensuring no data loss during the column creation and update process.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.route_clean', 'Column Drop', 194, 194, 'Pass', 'Dropped column route_length.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.route_clean', 'Row Count Confirmation', 194, 194, 'Pass', 'Row count confirmed. Confirmed the final row count is 194, ensuring no data loss during the column creation and update process.');



INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Initial Row Count', 130373, 130373, 'Pass', 'Initial row count before cleaning began.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Column Drop (Initial Set)', 130373, 130373, 'Pass', 'Dropped trip_short_name, direction_id, block_id, shape_id, wheelchair_accessible, and bikes_allowed.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Data Standardization (TRIM/UPPER)', 130373, 130373, 'Pass', 'Applied UPPER(TRIM()) to the trip_headsign column.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Null Value Check', 130373, 130373, 'Pass', 'Validation passed: No missing values found in route_id, trip_id, or trip_headsign.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Route ID Format Check', 130373, 130373, 'Pass', 'Added check_route_id_format constraint (5 digits). Validation passed: No errors.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Trip ID Format Check', 130373, 130373, 'Pass', 'Added check_trip_id_format constraint (8 digits). Validation passed: No errors.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Route ID Duplicates Check', 130373, 130373, 'WARNING', 'Duplicates found in route_id. This is expected as route_id is not the primary key of this table.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Trip ID Duplicates Check', 130373, 130373, 'Pass', 'Validation passed: No duplicates found in trip_id. Trip_id is suitable as the primary key.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Data Filtering: Retain Bus Routes Only', 130373, 110801, 'Pass', 'Rows deleted based on non-matching route_id. Removed non-bus trip records by keeping only rows whose route_id exists in the filtered silver.route_clean table.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Validation: Bus Route Type Check', 110801, 110801, 'Pass', 'Validation confirmed that every remaining trip record is associated with a bus route in silver.route_clean.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Data Filtering: Retain Weekday Trips Only', 110801, 32604, 'Pass', 'Rows deleted where service_id was not equal to 1 (retaining only weekday trips).');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Column Drop (Final Set)', 32604, 32604, 'Pass', 'Dropped the service_id column after filtering for weekday trips.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Negative Value Check (IDs)', 32604, 32604, 'Pass', 'Checked route_id and trip_id for negative values. No issues found.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.trip_clean', 'Final Row Count Check', 32604, 32604, 'Pass', 'Verified the final row count after all cleaning and filtering operations.');


INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Initial Table Audit and Row Count', 4310022, 4310022, 'Pass', 'Initial row count confirmed.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Structural Changes: Column Drops (Initial Set)', 4310022, 4310022, 'Pass', 'Schema altered. Columns dropped: pickup_type, drop_off_type, shape_dist_traveled, and stop_headsign.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Datatype Validation & TIME Conversion Failure', 4310022, 4310022, 'Fail', 'Attempted to change time columns to TIME datatype, but failed as many values are greater than 24:00:00.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Data Quality: Out-of-Range Time Count', 4310022, 4310022, 'Pass', 'Confirmed a significant number of records have a time value of 24 hours or greater, necessitating time conversion to seconds.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'NULL Value Check', 4310022, 4310022, 'Pass', 'Verified that key columns have no NULL values.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Key Analysis: stop_id Duplicates', 4310022, 4310022, 'Fail', 'Confirmed stop_id is NOT unique and cannot be a primary key alone.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Key Analysis: trip_id + stop_id Duplicates', 4310022, 4310022, 'Fail', 'Confirmed the composite key (trip_id + stop_id) is NOT unique.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Key Analysis: trip_id + stop_sequence Duplicates', 4310022, 4310022, 'Pass', 'Confirmed the composite key (trip_id + stop_sequence) IS unique, making it a viable natural key.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Data Filtering: Retain Bus Trips Only', 4310022, 1056103, 'Pass', 'Removed stop records whose trip_id did not exist in the filtered silver.trip_clean table.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Validation: Bus Trip ID Check (EXCEPT)', 1056103, 1056103, 'Pass', 'Validation via EXCEPT query confirmed no non-bus trip_id values remain post-filtering.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Schema Change: Add IDENTITY Column trip_stop_sequence_id', 1056103, 1056103, 'Pass', 'Added new IDENTITY column to serve as the surrogate primary key.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Structural Changes: Drop departure_time', 1056103, 1056103, 'Pass', 'Removed departure_time as the difference from arrival_time was negligible.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Structural Changes: Rename arrival_time', 1056103, 1056103, 'Pass', 'Renamed arrival_time to stopping_time to reflect its use as the single time point.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Feature Engineering: Add stopping_time_sec Column', 1056103, 1056103, 'Pass', 'Added new INTEGER column to represent time in seconds, bypassing the 24-hour limit of the TIME datatype.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Feature Engineering: Time Conversion to Seconds', 1056103, 1056103, 'Pass', 'Populated stopping_time_sec by converting the VARCHAR stopping_time (HH:MI:SS) into total seconds.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_clean', 'Negative Value Check (Numeric Columns)', 1056103, 1056103, 'Pass', 'Checked trip_id, stop_id, trip_stop_sequence_id, and stopping_time_sec for negative values. No issues found.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.stop_clean', 'Final Row Count Confirmation', 1056103, 1056103, 'Pass', 'Final row count confirmed after all cleaning and transformation steps.');


INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Initial Table Audit and Row Count', 9326, 9326, 'Pass', 'Initial row count confirmed. Confirmed starting row count of 9,326 before any modifications.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Structural Changes: Column Drops', 9326, 9326, 'Pass', 'Schema altered. Dropped 8 irrelevant columns, including stop_desc, zone_id, and stop_code.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Validation: Column Removal Check', 9326, 9326, 'Pass', 'Column removals visually validated. Verified the remaining columns in the table after the structural modification.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Post-Alter Row Count Confirmation', 9326, 9326, 'Pass', 'Row count confirmed. Confirmed row count remains 9,326 after structural changes.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Datatype Validation', 9326, 9326, 'Pass', 'Datatypes validated. Datatypes for all remaining columns were validated against the target schema.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'NULL Value Check', 9326, 9326, 'Pass', 'No NULL values found. Verified that key columns (stop_id, stop_name, stop_lat, stop_lon) have no NULL values.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Key Analysis: stop_id Uniqueness', 9326, 9326, 'Pass', 'Stop_id initially found unique.Check indicated stop_id was initially unique (contradicted by Step 10).');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Final Schema Check', 9326, 9326, 'Pass', 'Schema matches ERD. Final check confirmed all necessary columns are present and match the dimensional model.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Pre-Filter Row Count Check', 9326, 9326, 'Pass', 'Row count confirmed before filtering. Confirmed row count is still 9,326 before the bus-specific filtering step.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Key Analysis: stop_id Duplicates Recheck', 9326, 9326, 'Pass', 'Stop_id is not duplicated. Can be a primary key.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Pre-Filter Removal Count Check', 9326, 9326, 'Pass', 'Number of stops to be removed calculated. Calculated the number of stop_ids NOT related to bus data prior to execution of DELETE.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Data Filtering: Retain Bus Stops Only', 9326, 8538, 'Pass', 'Removed non-bus stop descriptions.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Validation: Non-Bus Stops Check', 8538, 8538, 'Pass', 'Zero non-bus stops found. Confirmed zero remaining stop_ids are outside the filtered silver.stop_clean table, validating the DELETE operation.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('stop_description_clean', 'Domain/Range Check (stop_id, lat, lon)', 8538, 8538, 'Pass', 'Checked stop_id for negative values, and stop_lat/stop_lon for valid geographic ranges (-90/90 and -180/180). No issues found.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.stop_description_clean', 'Final Row Count Confirmation', 8538, 8538, 'Pass', 'Final row count is 8060');




INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_clean', 'Initial Row Count', 207, 207, 'Pass', 'Initial row count after aggregation/initial load.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_clean', 'Column Drop (Initial)', 207, 207, 'Pass', 'Dropped "Route_Long_Name" and "Vehicles Overnigth".');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_clean', 'Column Rename', 207, 207, 'Pass', 'Renamed several columns to snake_case for consistency.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_clean', 'Negative Value Check (Numeric Columns)', 207, 207, 'Pass', 'Validation passed: No negative values found in numeric performance columns.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_clean', 'Route Name Duplicates Check', 207, 207, 'Pass', 'No duplicates founded in route_name column, suitable for join key.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_clean', 'Data Check: Initial Missing Value Tally ', 207, 207, 'Fail', 'Missing vehicle_am_peak values detected, requiring imputation. Initial data quality check identified NULL values in vehicle_am_peak. The total row count is 207.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_clean', 'Data Check: Missing Value Tally (Pre-Imputation)', 207, 207, 'Pass', 'Missing values detected in vehicle_am_peak column.Initial count found multiple NULL values in vehicle_am_peak, corresponding to 300-series "Blue Night Network" routes.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_clean', 'Data Transformation: Impute vehicle_am_peak', 207, 207, 'Pass', 'Vehicle_am_peak NULLs set to 0. Executed UPDATE to replace NULLs in vehicle_am_peak with 0, as these routes do not operate during morning peak hours (pre-6:00 AM).');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_clean', 'Data Check: Missing Value Tally', 207, 207, 'Pass', 'Final check shows 0 missing values in all monitored columns');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_clean', 'Data Filtering: Join to silver.route_clean', 207, 189, 'Pass', 'Rows deleted based on non-matching route_name. Removed rows from silver.transit_clean where route_name did not match any entry in silver.route_clean.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_clean', 'Post-Deletion Row Count Check', 189, 189, 'Pass', 'Row count reduced from.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_clean', 'Validation: Unmatched Routes Check', 189, 189, 'Pass', '0 unmatched routes found.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_clean', 'Schema Change: Add route_id column', 189, 189, 'Pass', 'Added route_id column to silver.transit_clean.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_clean', 'Data Population: Populate route_id', 189, 189, 'Pass', 'Populated route_id by joining with silver.route_clean on route_name. Row count remains 189.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_clean', 'Validation: route_id Match Check', 189, 189, 'Pass', 'Verified that 189 unique routes in silver.transit_clean successfully matched to a route_id from silver.route_clean.');



INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_trips', 'Table Creation: Join Route to Trip (Intermediate)', 189, 32261, 'Pass', 'Created initial silver.transit_trips table by joining silver.transit_clean with silver.trip_clean, resulting in 108,868 rows (routes x trips).');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_trips', 'Validation: Route Duplication Check (Trips)', 32261, 32261, 'Pass', 'Verified the table contains 189 distinct route_id values, confirming all original routes found matching trips.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_trips', 'Table Recreation: Join Route-Trip-Stop (Final)', 32261, 1051045, 'Pass', 'Recreated silver.transit_trips by joining silver.transit_clean, silver.trip_clean, and silver.stop_clean to include the trip_stop_sequence_id, resulting in 3,677,780 rows.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_trips', 'Validation: Row Count Consistency', 1051045, 1051045, 'Pass', 'Confirmed the final row count is consistent with the count of bus stops after filtering (3,677,780).');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_trips', 'Completeness Check (Critical Fields)', 1051045, 1051045, 'Pass', 'Checked route_name, riders_per_day, hours_per_day, kilometres_per_day, and route_id for NULL values. No issues found.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_trips', 'Negative Value Check (Measurements/Counts)', 1051045, 1051045, 'Pass', 'Checked riders, hours, kilometers, and vehicle peaks for negative values. No issues found.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_trips', 'Validation: Final Unique Route Check', 1051045, 1051045, 'Pass', 'Verified the final table contains 189 distinct route_id values.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes) 
VALUES ('silver.transit_trips', 'Schema Change: Final Table Rename', 1051045, 1051045, 'Pass', 'Renamed silver.transit_trips to silver.transit_final_clean as the last step of the silver layer processing.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_final_clean', 'Column Drop', 1051045, 1051045, 'Pass', 'Dropeed route_name column as it is redundant');


INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_final_clean', 'Completeness Check (Critical Fields)', 1051045, 1051045, 'Pass', 'Checked riders_per_day, hours_per_day, kilometres_per_day, and route_id for NULL values. No issues found.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_final_clean', 'Negative Value Check (All Numerics)', 1051045, 1051045, 'Pass', 'Checked all ID, count, measurement, and vehicle peak columns for negative values. No issues found.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_final_clean', 'Column Rename (Final)', 1051045, 1051045, 'Pass', 'Renamed customer_per_day to riders_per_day for clarity and consistency.');

INSERT INTO "silver.audit_log" (dataset, process_name, row_count_before, row_count_after, validation_result, notes)
VALUES ('silver.transit_final_clean', 'Final Table Check', 1051045, 1051045, 'Pass', 'Final schema check confirming all necessary columns are present and match the dimensional model.');


SELECT * FROM "silver.audit_log";