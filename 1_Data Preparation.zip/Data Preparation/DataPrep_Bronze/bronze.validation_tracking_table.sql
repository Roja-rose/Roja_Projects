
-- 1 -- 
-- Creating a validationg tracking table

CREATE TABLE bronze.validation_log (
    validation_id serial PRIMARY KEY,
	log_id integer REFERENCES bronze.load_log (log_id) ON DELETE CASCADE NOT NULL,
	validation_test_name character varying(100) NOT NULL,
	validation_description character varying (100) NOT NULL,
	validation_date date DEFAULT CURRENT_DATE NOT NULL,
    validation_outcome character varying(10) NOT NULL CHECK (validation_outcome IN ('Pass', 'Fail'))
);

-- 2 --
-- Loading data 

INSERT INTO bronze.validation_log (
    log_id,
    validation_test_name,
    validation_description,
    validation_outcome,
    validation_date  
)
VALUES

(1, 'File Load Verification',      'Confirm raw file successfully imported into Bronze schema.', 'Pass', '2025-10-18'),
(1, 'Row Count Match',             'Compare record count between source file and Bronze table.', 'Pass', '2025-10-18'),
(1, 'Column Structure Check',      'Verify expected columns and data types were loaded correctly.', 'Pass', '2025-10-18'),
(1, 'Corruption/Encoding Check',   'Validate no corrupted or unreadable records exist.', 'Pass', '2025-10-18'),

(2, 'File Load Verification',      'Confirm raw file successfully imported into Bronze schema.', 'Pass', '2025-10-18'),
(2, 'Row Count Match',             'Compare record count between source file and Bronze table.', 'Pass', '2025-10-18'),
(2, 'Column Structure Check',      'Verify expected columns and data types were loaded correctly.', 'Pass', '2025-10-18'),
(2, 'Corruption/Encoding Check',   'Validate no corrupted or unreadable records exist.', 'Pass', '2025-10-18'),

(3, 'File Load Verification',      'Confirm raw file successfully imported into Bronze schema.', 'Pass', '2025-10-18'),
(3, 'Row Count Match',             'Compare record count between source file and Bronze table.', 'Pass', '2025-10-18'),
(3, 'Column Structure Check',      'Verify expected columns and data types were loaded correctly.', 'Pass', '2025-10-18'),
(3, 'Corruption/Encoding Check',   'Validate no corrupted or unreadable records exist.', 'Pass', '2025-10-18'),

(4, 'File Load Verification',      'Confirm raw file successfully imported into Bronze schema.', 'Pass', '2025-10-20'),
(4, 'Row Count Match',             'Compare record count between source file and Bronze table.', 'Pass', '2025-10-20'),
(4, 'Column Structure Check',      'Verify expected columns and data types were loaded correctly.', 'Pass', '2025-10-20'),
(4, 'Corruption/Encoding Check',   'Validate no corrupted or unreadable records exist.', 'Pass', '2025-10-20'),

(5, 'File Load Verification',      'Confirm raw file successfully imported into Bronze schema.', 'Pass', '2025-10-18'),
(5, 'Row Count Match',             'Compare record count between source file and Bronze table.', 'Pass', '2025-10-18'),
(5, 'Column Structure Check',      'Verify expected columns and data types were loaded correctly.', 'Pass', '2025-10-18'),
(5, 'Corruption/Encoding Check',   'Validate no corrupted or unreadable records exist.', 'Pass', '2025-10-18');

SELECT * FROM bronze.validation_log;