
-- 1 --
-- Creating the bronze.load_log table
CREATE TABLE bronze.load_log (
    log_id          SERIAL PRIMARY KEY,
	table_name      VARCHAR(128) NOT NULL, 
    file_name       VARCHAR(255) NOT NULL, 
    rows_inserted   BIGINT,                
    load_date       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP, 
    loaded_by       VARCHAR(100) DEFAULT CURRENT_USER, 
    notes           TEXT                
	);

-- 2 --
--Loading data about bronze raw tables
INSERT INTO bronze.load_log (
    table_name,
    file_name,
    rows_inserted,
    load_date, 
    loaded_by,
    notes
)
VALUES 
    ('bronze.transit_raw', '2024 Fall Service Hours and Boardings by Route Nov BP v11.csv', 207, '2025-10-18', 'Olga Ornek', '--'),
    ('bronze.route_raw', 'routes.csv', 221, '2025-10-18', 'Olga Ornek', '--'),
    ('bronze.trip_raw', 'trips.csv', 130373, '2025-10-18', 'Olga Ornek', '--'),
    ('bronze.stop_raw', 'stop_time.csv', 4310022, '2025-10-20', 'Aarthi Sathiyamoorthy', '--'),
    ('bronze.stop_description_raw', 'stops.csv', 9326, '2025-10-18', 'Olga Ornek', '--');

Select * from bronze.load_log;